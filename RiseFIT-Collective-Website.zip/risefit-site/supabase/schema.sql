-- RiseFIT Collective — database schema
-- Run this once in Supabase → SQL Editor → New query → paste → Run.
-- Safe to re-run: it drops and recreates policies and functions, and only creates tables that don't exist.

-- =========================================================
-- Tables
-- =========================================================

create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  email text,
  full_name text,
  phone text,
  role text not null default 'client' check (role in ('client', 'trainer', 'owner')),
  membership text default 'Collective',
  injuries text,
  coach_note text,
  created_at timestamptz not null default now()
);

create table if not exists public.enrollments (
  id uuid primary key default gen_random_uuid(),
  first_name text not null,
  last_name text,
  email text not null,
  phone text,
  program text,
  goal text,
  notes text,
  sms_consent boolean not null default false,
  status text not null default 'new' check (status in ('new', 'contacted', 'enrolled', 'archived')),
  created_at timestamptz not null default now()
);

create table if not exists public.workouts (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  level text default 'All levels',
  focus text,
  duration_min int default 30,
  video_url text,
  thumbnail_url text,
  exercises jsonb not null default '[]'::jsonb, -- [{ "name": "Goblet squat", "sets": "4 × 10" }]
  status text not null default 'pending' check (status in ('pending', 'approved', 'changes')),
  review_note text,
  created_by uuid references public.profiles (id) on delete set null,
  approved_by uuid references public.profiles (id) on delete set null,
  approved_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.assignments (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.profiles (id) on delete cascade,
  workout_id uuid not null references public.workouts (id) on delete cascade,
  scheduled_for date not null default current_date,
  completed_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.workout_logs (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.profiles (id) on delete cascade,
  workout_id uuid references public.workouts (id) on delete set null,
  assignment_id uuid references public.assignments (id) on delete set null,
  completed jsonb not null default '[]'::jsonb,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.goals (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.profiles (id) on delete cascade,
  title text not null,
  current_value numeric not null default 0,
  target_value numeric not null default 100,
  unit text,
  target_date date,
  created_at timestamptz not null default now()
);

create table if not exists public.sessions (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  kind text not null default 'one_on_one' check (kind in ('one_on_one', 'group', 'check_in')),
  starts_at timestamptz not null,
  duration_min int not null default 60,
  location text,
  capacity int not null default 1 check (capacity > 0),
  created_at timestamptz not null default now()
);

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null references public.sessions (id) on delete cascade,
  client_id uuid not null references public.profiles (id) on delete cascade,
  status text not null default 'booked' check (status in ('booked', 'cancelled')),
  created_at timestamptz not null default now(),
  unique (session_id, client_id)
);

create index if not exists assignments_client_idx on public.assignments (client_id, scheduled_for);
create index if not exists logs_client_idx on public.workout_logs (client_id, created_at desc);
create index if not exists sessions_start_idx on public.sessions (starts_at);
create index if not exists bookings_client_idx on public.bookings (client_id);

-- =========================================================
-- Helper functions
-- =========================================================

create or replace function public.my_role()
returns text
language sql
stable
security definer
set search_path = public
as $$
  select role from public.profiles where id = auth.uid();
$$;

create or replace function public.is_staff()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(public.my_role() in ('owner', 'trainer'), false);
$$;

create or replace function public.is_owner()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(public.my_role() = 'owner', false);
$$;

-- New sign-ups get a client profile automatically.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email, full_name, phone)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data ->> 'full_name', split_part(new.email, '@', 1)),
    new.raw_user_meta_data ->> 'phone'
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Only the owner can change roles; clients can't edit their own coach note.
create or replace function public.protect_profile_fields()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  -- auth.uid() is null when you run SQL in the Supabase editor, which is allowed.
  if auth.uid() is not null and new.role is distinct from old.role and not public.is_owner() then
    raise exception 'Only the owner can change roles';
  end if;
  if auth.uid() is not null and not public.is_staff() then
    new.coach_note := old.coach_note;
    new.membership := old.membership;
  end if;
  return new;
end;
$$;

drop trigger if exists protect_profile on public.profiles;
create trigger protect_profile
  before update on public.profiles
  for each row execute function public.protect_profile_fields();

-- Nothing goes live to clients until the OWNER approves it.
create or replace function public.guard_workout_approval()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if auth.uid() is null then
    return new;
  end if;
  if tg_op = 'INSERT' then
    if new.status = 'approved' and not public.is_owner() then
      new.status := 'pending';
    end if;
    if new.status = 'approved' then
      new.approved_by := auth.uid();
      new.approved_at := now();
    end if;
    return new;
  end if;
  if new.status is distinct from old.status and new.status in ('approved', 'changes') and not public.is_owner() then
    raise exception 'Only the owner can approve workouts or request changes';
  end if;
  -- Any edit by a trainer to an approved workout sends it back for review.
  if old.status = 'approved' and not public.is_owner() then
    new.status := 'pending';
  end if;
  if new.status = 'approved' and old.status is distinct from 'approved' then
    new.approved_by := auth.uid();
    new.approved_at := now();
  end if;
  return new;
end;
$$;

drop trigger if exists guard_workout on public.workouts;
create trigger guard_workout
  before insert or update on public.workouts
  for each row execute function public.guard_workout_approval();

-- Upcoming sessions with how many spots are taken (clients can't see other people's bookings).
create or replace function public.upcoming_sessions(days_ahead int default 14)
returns table (
  id uuid,
  title text,
  kind text,
  starts_at timestamptz,
  duration_min int,
  location text,
  capacity int,
  booked int,
  mine boolean
)
language sql
stable
security definer
set search_path = public
as $$
  select s.id, s.title, s.kind, s.starts_at, s.duration_min, s.location, s.capacity,
         (select count(*)::int from public.bookings b where b.session_id = s.id and b.status = 'booked') as booked,
         exists (select 1 from public.bookings b where b.session_id = s.id and b.client_id = auth.uid() and b.status = 'booked') as mine
  from public.sessions s
  where s.starts_at > now()
    and s.starts_at < now() + make_interval(days => days_ahead)
    and auth.uid() is not null
  order by s.starts_at;
$$;

-- Book a spot, respecting capacity.
create or replace function public.book_session(p_session uuid)
returns text
language plpgsql
security definer
set search_path = public
as $$
declare
  cap int;
  taken int;
  starts timestamptz;
begin
  if auth.uid() is null then
    raise exception 'Sign in to book';
  end if;
  select capacity, starts_at into cap, starts from public.sessions where id = p_session for update;
  if cap is null then
    raise exception 'That session no longer exists';
  end if;
  if starts <= now() then
    raise exception 'That session has already started';
  end if;
  select count(*) into taken from public.bookings where session_id = p_session and status = 'booked';
  if taken >= cap then
    raise exception 'That session is full';
  end if;
  insert into public.bookings (session_id, client_id, status)
  values (p_session, auth.uid(), 'booked')
  on conflict (session_id, client_id) do update set status = 'booked', created_at = now();
  return 'booked';
end;
$$;

-- Cancel your own booking up to 24 hours before (staff can cancel any time).
create or replace function public.cancel_booking(p_booking uuid)
returns text
language plpgsql
security definer
set search_path = public
as $$
declare
  owner_id uuid;
  starts timestamptz;
begin
  select b.client_id, s.starts_at into owner_id, starts
  from public.bookings b join public.sessions s on s.id = b.session_id
  where b.id = p_booking;
  if owner_id is null then
    raise exception 'Booking not found';
  end if;
  if owner_id <> auth.uid() and not public.is_staff() then
    raise exception 'You can only cancel your own bookings';
  end if;
  if not public.is_staff() and starts - now() < interval '24 hours' then
    raise exception 'Bookings can be cancelled up to 24 hours before the session. Message your coach for anything later.';
  end if;
  update public.bookings set status = 'cancelled' where id = p_booking;
  return 'cancelled';
end;
$$;

-- =========================================================
-- Row level security
-- =========================================================

alter table public.profiles enable row level security;
alter table public.enrollments enable row level security;
alter table public.workouts enable row level security;
alter table public.assignments enable row level security;
alter table public.workout_logs enable row level security;
alter table public.goals enable row level security;
alter table public.sessions enable row level security;
alter table public.bookings enable row level security;

-- profiles
drop policy if exists "profiles: read own or staff" on public.profiles;
create policy "profiles: read own or staff" on public.profiles
  for select using (id = auth.uid() or public.is_staff());
drop policy if exists "profiles: update own or staff" on public.profiles;
create policy "profiles: update own or staff" on public.profiles
  for update using (id = auth.uid() or public.is_staff());

-- enrollments: anyone can submit the website form; only staff can read it
drop policy if exists "enrollments: anyone can submit" on public.enrollments;
create policy "enrollments: anyone can submit" on public.enrollments
  for insert to anon, authenticated with check (status = 'new');
drop policy if exists "enrollments: staff read" on public.enrollments;
create policy "enrollments: staff read" on public.enrollments
  for select using (public.is_staff());
drop policy if exists "enrollments: staff update" on public.enrollments;
create policy "enrollments: staff update" on public.enrollments
  for update using (public.is_staff());
drop policy if exists "enrollments: owner delete" on public.enrollments;
create policy "enrollments: owner delete" on public.enrollments
  for delete using (public.is_owner());

-- workouts: clients see approved only
drop policy if exists "workouts: read" on public.workouts;
create policy "workouts: read" on public.workouts
  for select using (status = 'approved' and auth.uid() is not null or public.is_staff());
drop policy if exists "workouts: staff insert" on public.workouts;
create policy "workouts: staff insert" on public.workouts
  for insert with check (public.is_staff());
drop policy if exists "workouts: staff update" on public.workouts;
create policy "workouts: staff update" on public.workouts
  for update using (public.is_staff());
drop policy if exists "workouts: owner delete" on public.workouts;
create policy "workouts: owner delete" on public.workouts
  for delete using (public.is_owner());

-- assignments
drop policy if exists "assignments: read own or staff" on public.assignments;
create policy "assignments: read own or staff" on public.assignments
  for select using (client_id = auth.uid() or public.is_staff());
drop policy if exists "assignments: staff insert" on public.assignments;
create policy "assignments: staff insert" on public.assignments
  for insert with check (public.is_staff());
drop policy if exists "assignments: update own or staff" on public.assignments;
create policy "assignments: update own or staff" on public.assignments
  for update using (client_id = auth.uid() or public.is_staff());
drop policy if exists "assignments: staff delete" on public.assignments;
create policy "assignments: staff delete" on public.assignments
  for delete using (public.is_staff());

-- workout logs
drop policy if exists "logs: read own or staff" on public.workout_logs;
create policy "logs: read own or staff" on public.workout_logs
  for select using (client_id = auth.uid() or public.is_staff());
drop policy if exists "logs: insert own" on public.workout_logs;
create policy "logs: insert own" on public.workout_logs
  for insert with check (client_id = auth.uid());

-- goals
drop policy if exists "goals: read own or staff" on public.goals;
create policy "goals: read own or staff" on public.goals
  for select using (client_id = auth.uid() or public.is_staff());
drop policy if exists "goals: insert own or staff" on public.goals;
create policy "goals: insert own or staff" on public.goals
  for insert with check (client_id = auth.uid() or public.is_staff());
drop policy if exists "goals: update own or staff" on public.goals;
create policy "goals: update own or staff" on public.goals
  for update using (client_id = auth.uid() or public.is_staff());
drop policy if exists "goals: delete own or staff" on public.goals;
create policy "goals: delete own or staff" on public.goals
  for delete using (client_id = auth.uid() or public.is_staff());

-- sessions
drop policy if exists "sessions: signed-in read" on public.sessions;
create policy "sessions: signed-in read" on public.sessions
  for select using (auth.uid() is not null);
drop policy if exists "sessions: staff write" on public.sessions;
create policy "sessions: staff write" on public.sessions
  for all using (public.is_staff()) with check (public.is_staff());

-- bookings (clients book and cancel through the functions above)
drop policy if exists "bookings: read own or staff" on public.bookings;
create policy "bookings: read own or staff" on public.bookings
  for select using (client_id = auth.uid() or public.is_staff());
drop policy if exists "bookings: staff write" on public.bookings;
create policy "bookings: staff write" on public.bookings
  for all using (public.is_staff()) with check (public.is_staff());

grant execute on function public.upcoming_sessions(int) to authenticated;
grant execute on function public.book_session(uuid) to authenticated;
grant execute on function public.cancel_booking(uuid) to authenticated;

-- =========================================================
-- After you create your own account on the site, make yourself the owner:
--   update public.profiles set role = 'owner' where email = 'you@example.com';
-- To add a trainer:
--   update public.profiles set role = 'trainer' where email = 'trainer@example.com';
-- =========================================================

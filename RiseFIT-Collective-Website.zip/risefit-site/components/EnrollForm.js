'use client';

import { useActionState } from 'react';
import { submitEnrollment } from '@/app/actions';

export default function EnrollForm() {
  const [state, action, pending] = useActionState(submitEnrollment, null);

  if (state?.ok) {
    return (
      <div className="stack" role="status">
        <p className="hero-lede" style={{ maxWidth: '22ch' }}>
          {state.message}
        </p>
      </div>
    );
  }

  return (
    <form action={action} className="form-grid">
      <label className="line-field">
        First name
        <input name="first_name" autoComplete="given-name" required />
      </label>
      <label className="line-field">
        Last name
        <input name="last_name" autoComplete="family-name" />
      </label>
      <label className="line-field">
        Email
        <input name="email" type="email" autoComplete="email" required />
      </label>
      <label className="line-field">
        Phone
        <input name="phone" type="tel" autoComplete="tel" />
      </label>
      <label className="line-field">
        Program
        <select name="program" defaultValue="Not sure yet">
          <option>Group classes</option>
          <option>Personal coaching</option>
          <option>Remote training</option>
          <option>Not sure yet</option>
        </select>
      </label>
      <label className="line-field">
        Main goal
        <select name="goal" defaultValue="Build strength">
          <option>Build strength</option>
          <option>Lose weight</option>
          <option>More energy and confidence</option>
          <option>Train for an event</option>
          <option>Something else</option>
        </select>
      </label>
      <label className="line-field full">
        Anything we should know?
        <textarea name="notes" rows={3} placeholder="Injuries, schedule, what you’d love to work on" />
      </label>
      <div className="form-foot full">
        <label className="check">
          <input type="checkbox" name="sms_consent" /> Text me about bookings and events
        </label>
        <button type="submit" className="btn btn-light" disabled={pending}>
          {pending ? 'Sending…' : 'Request enrollment'}
        </button>
      </div>
      {state && !state.ok && (
        <p className="form-msg err full" role="alert">
          {state.message}
        </p>
      )}
    </form>
  );
}

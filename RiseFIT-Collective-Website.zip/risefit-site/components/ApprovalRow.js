import Video from '@/components/Video';
import { approveWorkout, requestChanges, resubmitWorkout } from '@/app/admin/actions';
import { fmtDate } from '@/lib/format';

// One workout in the approval queue. Only the owner sees Approve / Request changes.
export default function ApprovalRow({ w, isOwner, compact = false }) {
  const exercises = Array.isArray(w.exercises) ? w.exercises : [];
  return (
    <li style={{ display: 'block' }}>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 18, alignItems: 'center' }}>
        <img className="thumb" src={w.thumbnail_url || '/images/class.jpg'} alt="" />
        <div className="row-main">
          <strong>{w.title}</strong>
          <span className="meta">
            {w.author?.full_name ? `By ${w.author.full_name}, ` : ''}
            {w.duration_min} min, {w.level}, submitted {fmtDate(w.created_at, { month: 'short', day: 'numeric' })}
          </span>
        </div>
        {w.status === 'changes' ? <span className="badge badge-warn">Changes requested</span> : <span className="badge">Waiting for review</span>}
      </div>

      {w.status === 'changes' && w.review_note && (
        <p className="alert" style={{ marginTop: 12 }}>
          Owner’s note: {w.review_note}
        </p>
      )}

      {!compact && (
        <details style={{ marginTop: 12 }}>
          <summary className="link" style={{ cursor: 'pointer', display: 'inline-block', padding: '8px 0' }}>
            Preview
          </summary>
          <div style={{ marginTop: 14 }}>
            <Video url={w.video_url} title={w.title} />
            {w.description && <p style={{ color: 'var(--graphite)', marginBottom: 12 }}>{w.description}</p>}
            {exercises.length > 0 && (
              <ul className="checklist">
                {exercises.map((ex, i) => (
                  <li key={i} className="check-row" style={{ cursor: 'default' }}>
                    <span className="check-name">{ex.name}</span>
                    <span className="check-sets">{ex.sets}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </details>
      )}

      <div className="inline-form" style={{ marginTop: 12 }}>
        {isOwner && w.status === 'pending' ? (
          <>
            <form action={approveWorkout}>
              <input type="hidden" name="id" value={w.id} />
              <button className="btn btn-sm">Approve and publish</button>
            </form>
            <form action={requestChanges} className="inline-form" style={{ flex: '1 1 320px' }}>
              <input type="hidden" name="id" value={w.id} />
              <input name="review_note" placeholder="What should change?" aria-label="What should change?" style={{ flex: '1 1 200px' }} />
              <button className="btn btn-ghost btn-sm">Request changes</button>
            </form>
          </>
        ) : null}
        {w.status === 'changes' ? (
          <form action={resubmitWorkout}>
            <input type="hidden" name="id" value={w.id} />
            <button className="btn btn-ghost btn-sm">Resubmit for review</button>
          </form>
        ) : null}
        {!isOwner && w.status === 'pending' ? <span className="meta">The owner will review this before clients can see it.</span> : null}
      </div>
    </li>
  );
}

'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { signOut } from '@/app/login/actions';

// Black sidebar + main area, shared by the client portal and the owner studio.
export default function AppShell({ links, label, name, roleLabel, initials, switchLink, children }) {
  const path = usePathname();
  const isActive = (href) => (href === links[0].href ? path === href : path.startsWith(href));

  return (
    <div className="app">
      <aside className="side">
        <div>
          <Link href="/" className="side-logo" aria-label="RiseFIT Collective website">
            <img src="/images/logo-white.png" alt="RiseFIT Collective" />
          </Link>
          {label && <div className="side-label">{label}</div>}
        </div>
        <nav className="side-nav" aria-label={label || 'Portal'}>
          {links.map((l) => (
            <Link key={l.href} href={l.href} className={isActive(l.href) ? 'is-active' : ''} aria-current={isActive(l.href) ? 'page' : undefined}>
              {l.label}
              {l.count ? <span className="side-count">{l.count}</span> : null}
            </Link>
          ))}
        </nav>
        <div className="side-foot">
          <div className="who">
            <span className="avatar" aria-hidden="true">
              {initials}
            </span>
            <div>
              {name}
              <small>{roleLabel}</small>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 18, flexWrap: 'wrap' }}>
            {switchLink && <Link href={switchLink.href}>{switchLink.label}</Link>}
            <form action={signOut}>
              <button type="submit">Sign out</button>
            </form>
          </div>
        </div>
      </aside>
      <main className="main">
        <div className="main-inner">{children}</div>
      </main>
    </div>
  );
}

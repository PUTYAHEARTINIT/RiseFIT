'use client';

import { useState } from 'react';

// Program list: hovering, focusing or tapping a program swaps the photo beside it.
export default function Programs({ programs }) {
  const [active, setActive] = useState(programs[0]?.id);

  return (
    <div className="programs">
      <div>
        <ul className="program-list">
          {programs.map((p) => (
            <li key={p.id} className={`program ${active === p.id ? 'is-active' : ''}`}>
              <button
                type="button"
                className="program-btn"
                aria-expanded={active === p.id}
                onMouseEnter={() => setActive(p.id)}
                onFocus={() => setActive(p.id)}
                onClick={() => setActive(p.id)}
              >
                <span className="program-name">{p.name}</span>
                <span className="program-price">{p.price}</span>
                <span className="program-desc">{p.description}</span>
              </button>
            </li>
          ))}
        </ul>
        <div className="program-cta btn-row">
          <a href="#enroll" className="btn">
            Book a free intro
          </a>
          <a href="#membership" className="btn btn-ghost">
            Compare memberships
          </a>
        </div>
      </div>
      <div className="program-stage" aria-hidden="true">
        {programs.map((p) => (
          <img key={p.id} src={p.image} alt="" className={active === p.id ? 'is-active' : ''} />
        ))}
      </div>
    </div>
  );
}

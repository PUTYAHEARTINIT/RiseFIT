import Link from 'next/link';

// Shown on /portal and /admin until the Supabase keys are added.
export default function SetupNotice() {
  return (
    <main className="setup">
      <img src="/images/logo-black.png" alt="RiseFIT Collective" style={{ height: 80, width: 'auto', marginBottom: 32 }} />
      <h1>Connect the database</h1>
      <p style={{ marginBottom: 20 }}>The portal needs Supabase before anyone can sign in. It takes about ten minutes:</p>
      <ol className="stack">
        <li>Create a free project at supabase.com.</li>
        <li>
          In its SQL Editor, run the file <code>supabase/schema.sql</code> from this project.
        </li>
        <li>
          Copy the project URL and anon key from Project Settings, API into <code>NEXT_PUBLIC_SUPABASE_URL</code> and{' '}
          <code>NEXT_PUBLIC_SUPABASE_ANON_KEY</code> in Vercel (or <code>.env.local</code>).
        </li>
        <li>Redeploy, create your account, then make yourself the owner (see the README).</li>
      </ol>
      <p style={{ marginTop: 32 }}>
        <Link href="/" className="link">
          Back to the website
        </Link>
      </p>
    </main>
  );
}

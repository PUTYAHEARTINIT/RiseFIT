'use client';

import { useState, useTransition } from 'react';
import { logWorkout } from '@/app/portal/actions';

// Exercise checklist with a progress ring. "Finish and log" saves it to the client's history.
export default function WorkoutLogger({ workout, assignmentId, heading }) {
  const exercises = Array.isArray(workout.exercises) ? workout.exercises : [];
  const [done, setDone] = useState([]);
  const [notes, setNotes] = useState('');
  const [result, setResult] = useState(null);
  const [pending, start] = useTransition();

  const pct = exercises.length ? Math.round((done.length / exercises.length) * 100) : 0;
  const toggle = (i) => setDone((d) => (d.includes(i) ? d.filter((x) => x !== i) : [...d, i]));

  const finish = () =>
    start(async () => {
      const res = await logWorkout({ workoutId: workout.id, assignmentId, completed: done, notes });
      setResult(res);
    });

  if (result?.ok) {
    return (
      <div className="today">
        <div className="ring" style={{ '--p': 100 }}>
          <div className="ring-inner">
            <strong>Done</strong>
          </div>
        </div>
        <div>
          <h2>Workout logged</h2>
          <p className="meta">Nice work. Your coach can see it now, and your streak just grew.</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="today">
        <div className="ring" style={{ '--p': pct }} role="img" aria-label={`${done.length} of ${exercises.length} exercises done`}>
          <div className="ring-inner">
            <div>
              <strong>{done.length}</strong>
              <span>
                <br />
                of {exercises.length}
              </span>
            </div>
          </div>
        </div>
        <div>
          {heading && <div className="page-date">{heading}</div>}
          <h2>{workout.title}</h2>
          <div className="chips">
            <span className="badge">Coach approved</span>
            {workout.duration_min ? <span className="badge badge-line">{workout.duration_min} min</span> : null}
            {workout.level ? <span className="badge badge-line">{workout.level}</span> : null}
          </div>
        </div>
      </div>

      {exercises.length ? (
        <ul className="checklist">
          {exercises.map((ex, i) => (
            <li key={i}>
              <button type="button" className="check-row" aria-pressed={done.includes(i)} onClick={() => toggle(i)}>
                <span className="check-box" aria-hidden="true">
                  {done.includes(i) && (
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="3">
                      <path d="M5 12l5 5L20 7" />
                    </svg>
                  )}
                </span>
                <span className="check-name">{ex.name}</span>
                <span className="check-sets">{ex.sets}</span>
              </button>
            </li>
          ))}
        </ul>
      ) : (
        <p className="empty">Follow along with the video, then log it below.</p>
      )}

      <label className="field" style={{ marginBottom: 18 }}>
        Notes for your coach (optional)
        <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} placeholder="Weights used, how it felt, anything that hurt" />
      </label>
      {result?.error && (
        <p className="alert alert-err" role="alert" style={{ marginBottom: 12 }}>
          {result.error}
        </p>
      )}
      <button type="button" className="btn" onClick={finish} disabled={pending}>
        {pending ? 'Saving…' : 'Finish and log workout'}
      </button>
    </div>
  );
}

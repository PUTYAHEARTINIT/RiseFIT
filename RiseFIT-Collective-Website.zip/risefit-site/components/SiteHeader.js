import Link from 'next/link';
import { site } from '@/lib/site';

export default function SiteHeader() {
  return (
    <>
      <div className="announce">
        {site.announcement.text}{' '}
        <a href="/#enroll">{site.announcement.linkText}</a>
      </div>
      <header className="site-header">
        <div className="wrap">
          <Link href="/" className="site-logo" aria-label="RiseFIT Collective home">
            <img src="/images/logo-black.png" alt="RiseFIT Collective" />
          </Link>
          <nav className="site-nav" aria-label="Main">
            <a href="/#about">About</a>
            <a href="/#programs">Programs</a>
            <a href="/#community">Community</a>
            <a href="/#membership">Membership</a>
          </nav>
          <div className="header-actions">
            <Link href="/login" className="plain">
              Client login
            </Link>
            <a href="/#enroll" className="btn btn-sm">
              Join the Collective
            </a>
          </div>
        </div>
      </header>
    </>
  );
}

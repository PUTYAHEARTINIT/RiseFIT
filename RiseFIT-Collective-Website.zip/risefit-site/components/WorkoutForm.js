// Form used to add and edit workouts in the owner studio.
export default function WorkoutForm({ action, workout, isOwner, submitLabel }) {
  const w = workout || {};
  const exercises = Array.isArray(w.exercises) ? w.exercises.map((e) => (e.sets ? `${e.name} | ${e.sets}` : e.name)).join('\n') : '';
  return (
    <form action={action} className="stack">
      {w.id && <input type="hidden" name="id" value={w.id} />}
      <label className="field">
        Title
        <input name="title" defaultValue={w.title || ''} placeholder="Lower body strength" required />
      </label>
      <label className="field">
        Short description
        <textarea name="description" defaultValue={w.description || ''} placeholder="What it trains and who it’s for" />
      </label>
      <div className="grid-2">
        <label className="field">
          Level
          <select name="level" defaultValue={w.level || 'All levels'}>
            <option>All levels</option>
            <option>Beginner</option>
            <option>Intermediate</option>
            <option>Advanced</option>
          </select>
        </label>
        <label className="field">
          Length in minutes
          <input name="duration_min" type="number" min="5" max="180" defaultValue={w.duration_min || 30} />
        </label>
        <label className="field">
          Focus
          <input name="focus" defaultValue={w.focus || ''} placeholder="Glutes, core, mobility" />
        </label>
      </div>
      <label className="field">
        Video link
        <input name="video_url" type="url" defaultValue={w.video_url || ''} placeholder="YouTube, Vimeo or a direct .mp4 link" />
      </label>
      <label className="field">
        Thumbnail image link (optional)
        <input name="thumbnail_url" type="url" defaultValue={w.thumbnail_url || ''} placeholder="https://…" />
      </label>
      <label className="field">
        Exercises, one per line: name | sets and reps
        <textarea name="exercises" rows={7} defaultValue={exercises} placeholder={'Dynamic warm-up | 8 min\nGoblet squat | 4 × 10\nRomanian deadlift | 3 × 12'} />
      </label>
      {isOwner && !w.id && (
        <label className="check">
          <input type="checkbox" name="publish" defaultChecked /> Publish to clients now (skip the approval queue)
        </label>
      )}
      {!isOwner && <p className="meta">Saving sends this to the owner for approval before clients can see it.</p>}
      <button className="btn" style={{ alignSelf: 'flex-start' }}>
        {submitLabel}
      </button>
    </form>
  );
}

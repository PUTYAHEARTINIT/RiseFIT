import { embedUrl } from '@/lib/format';

export default function Video({ url, title }) {
  if (!url) return null;
  const embed = embedUrl(url);
  return (
    <div className="video">
      {embed ? (
        <iframe src={embed} title={title || 'Workout video'} allow="autoplay; fullscreen; picture-in-picture" allowFullScreen />
      ) : (
        <video src={url} controls playsInline preload="metadata" />
      )}
    </div>
  );
}

'use client';

import { useActionState } from 'react';

// Cancel button that shows the reason if the cancellation isn't allowed.
export default function CancelButton({ id, action, label = 'Cancel' }) {
  const [state, formAction, pending] = useActionState(async (_prev, fd) => action(fd), null);
  return (
    <form action={formAction} className="inline-form">
      <input type="hidden" name="id" value={id} />
      <button className="btn btn-ghost btn-sm" disabled={pending}>
        {pending ? 'Cancelling…' : label}
      </button>
      {state?.error && (
        <span className="meta" role="alert" style={{ color: 'var(--danger)', maxWidth: 260 }}>
          {state.error}
        </span>
      )}
    </form>
  );
}

'use client';

import { useMemo, useState, useTransition } from 'react';
import { useRouter } from 'next/navigation';
import { bookSession } from '@/app/portal/actions';

const KINDS = [
  { id: 'all', label: 'Everything' },
  { id: 'one_on_one', label: '1:1 sessions' },
  { id: 'group', label: 'Group classes' },
  { id: 'check_in', label: 'Check-ins' },
];

const TZ = 'America/New_York';
const dayKey = (d) => new Date(d).toLocaleDateString('en-CA', { timeZone: TZ });

export default function BookingPicker({ sessions }) {
  const router = useRouter();
  const [kind, setKind] = useState('all');
  const filtered = useMemo(() => sessions.filter((s) => kind === 'all' || s.kind === kind), [sessions, kind]);
  const days = useMemo(() => [...new Set(filtered.map((s) => dayKey(s.starts_at)))], [filtered]);
  const [day, setDay] = useState(null);
  const activeDay = days.includes(day) ? day : days[0];
  const [picked, setPicked] = useState(null);
  const [msg, setMsg] = useState(null);
  const [pending, start] = useTransition();

  const slots = filtered.filter((s) => dayKey(s.starts_at) === activeDay);
  const chosen = sessions.find((s) => s.id === picked);

  const confirm = () =>
    start(async () => {
      const res = await bookSession(picked);
      if (res?.error) setMsg({ err: true, text: res.error });
      else {
        setMsg({ err: false, text: `Booked: ${chosen.title}, ${new Date(chosen.starts_at).toLocaleString('en-US', { timeZone: TZ, weekday: 'long', hour: 'numeric', minute: '2-digit' })}. See you there.` });
        setPicked(null);
        router.refresh();
      }
    });

  return (
    <div className="stack" style={{ gap: 22 }}>
      <div className="choice-row" role="group" aria-label="Session type">
        {KINDS.map((k) => (
          <button key={k.id} type="button" className="choice" aria-pressed={kind === k.id} onClick={() => { setKind(k.id); setPicked(null); }}>
            {k.label}
          </button>
        ))}
      </div>

      {days.length === 0 ? (
        <p className="empty">No open times in the next two weeks. Message your coach and they’ll add one.</p>
      ) : (
        <>
          <div className="choice-row" role="group" aria-label="Day">
            {days.map((d) => {
              const date = new Date(d + 'T12:00:00');
              return (
                <button key={d} type="button" className="choice" aria-pressed={activeDay === d} onClick={() => { setDay(d); setPicked(null); }}>
                  {date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
                </button>
              );
            })}
          </div>

          <div className="slots">
            {slots.map((s) => {
              const left = s.capacity - s.booked;
              const full = left <= 0;
              return (
                <button
                  key={s.id}
                  type="button"
                  className="slot"
                  aria-pressed={picked === s.id}
                  disabled={full || s.mine}
                  onClick={() => setPicked(s.id)}
                >
                  <span className="slot-time">
                    {new Date(s.starts_at).toLocaleTimeString('en-US', { timeZone: TZ, hour: 'numeric', minute: '2-digit' })}
                  </span>
                  <span>{s.title}</span>
                  <span className="meta">
                    {s.mine ? 'You’re booked' : full ? 'Full' : s.capacity > 1 ? `${left} of ${s.capacity} spots left` : 'Open'}
                    {s.location ? `, ${s.location}` : ''}
                  </span>
                </button>
              );
            })}
          </div>
        </>
      )}

      <div className="inline-form" style={{ justifyContent: 'space-between', borderTop: '1px solid var(--line)', paddingTop: 20 }}>
        <span className="meta" role="status">
          {msg ? <span style={{ color: msg.err ? 'var(--danger)' : 'var(--iris)' }}>{msg.text}</span> : chosen ? `${chosen.title}, ${chosen.duration_min} min` : 'Pick a time to continue'}
        </span>
        <button type="button" className="btn" disabled={!picked || pending} onClick={confirm}>
          {pending ? 'Booking…' : 'Confirm booking'}
        </button>
      </div>
    </div>
  );
}

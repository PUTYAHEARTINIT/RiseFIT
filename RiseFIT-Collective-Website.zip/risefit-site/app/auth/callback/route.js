import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';

// Handles the links in confirmation and sign-in emails.
export async function GET(request) {
  const url = new URL(request.url);
  const code = url.searchParams.get('code');
  const tokenHash = url.searchParams.get('token_hash');
  const type = url.searchParams.get('type');
  const nextParam = url.searchParams.get('next') || '';
  const next = nextParam.startsWith('/portal') || nextParam.startsWith('/admin') ? nextParam : '/portal';

  const supabase = await createClient();
  let ok = false;

  if (code) {
    const { error } = await supabase.auth.exchangeCodeForSession(code);
    ok = !error;
  } else if (tokenHash && type) {
    const { error } = await supabase.auth.verifyOtp({ type, token_hash: tokenHash });
    ok = !error;
  }

  if (!ok) return NextResponse.redirect(new URL('/login?error=link', url.origin));

  // Send staff to the owner studio unless a specific page was requested.
  if (!nextParam) {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    const { data: profile } = await supabase.from('profiles').select('role').eq('id', user.id).single();
    if (profile?.role === 'owner' || profile?.role === 'trainer') {
      return NextResponse.redirect(new URL('/admin', url.origin));
    }
  }
  return NextResponse.redirect(new URL(next, url.origin));
}

'use server';

import { createClient, isConfigured } from '@/lib/supabase/server';

// Website enrollment form → enrollments table → shows up in the owner studio.
export async function submitEnrollment(_prev, formData) {
  const get = (k) => String(formData.get(k) || '').trim();
  const entry = {
    first_name: get('first_name'),
    last_name: get('last_name'),
    email: get('email').toLowerCase(),
    phone: get('phone'),
    program: get('program'),
    goal: get('goal'),
    notes: get('notes'),
    sms_consent: formData.get('sms_consent') === 'on',
  };

  if (!entry.first_name || !entry.email) {
    return { ok: false, message: 'Add your first name and email so we can reach you.' };
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(entry.email)) {
    return { ok: false, message: 'That email address looks incomplete. Check it and try again.' };
  }
  if (!isConfigured()) {
    return { ok: false, message: 'Enrollment isn’t connected yet. Add the Supabase keys to turn it on.' };
  }

  const supabase = await createClient();
  const { error } = await supabase.from('enrollments').insert(entry);
  if (error) {
    return { ok: false, message: 'Your request didn’t send. Try again, or email us directly.' };
  }
  return { ok: true, message: `Thanks, ${entry.first_name}. We’ll be in touch to book your intro session.` };
}

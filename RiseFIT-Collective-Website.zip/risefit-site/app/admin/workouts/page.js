import Link from 'next/link';
import { requireStaff } from '@/lib/auth';
import WorkoutForm from '@/components/WorkoutForm';
import { createWorkout, deleteWorkout } from '../actions';

export const dynamic = 'force-dynamic';

const STATUS = {
  approved: <span className="badge badge-ink">Live</span>,
  pending: <span className="badge">Waiting for review</span>,
  changes: <span className="badge badge-warn">Changes requested</span>,
};

export default async function AdminWorkouts() {
  const { supabase, profile } = await requireStaff();
  const { data: workouts } = await supabase.from('workouts').select('*').order('created_at', { ascending: false });
  const isOwner = profile.role === 'owner';

  return (
    <>
      <div className="page-head">
        <div>
          <div className="page-date">{workouts?.filter((w) => w.status === 'approved').length || 0} live for clients</div>
          <h1 className="page-title">Workout library</h1>
        </div>
      </div>

      <details className="drawer" id="new">
        <summary>Add a workout</summary>
        <WorkoutForm action={createWorkout} isOwner={isOwner} submitLabel={isOwner ? 'Save workout' : 'Send for approval'} />
      </details>

      <section className="panel">
        {workouts?.length ? (
          <div className="table-wrap">
            <table className="table">
              <thead>
                <tr>
                  <th scope="col">Workout</th>
                  <th scope="col">Level</th>
                  <th scope="col">Length</th>
                  <th scope="col">Status</th>
                  <th scope="col">
                    <span className="visually-hidden">Actions</span>
                  </th>
                </tr>
              </thead>
              <tbody>
                {workouts.map((w) => (
                  <tr key={w.id}>
                    <td>
                      <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
                        <img className="thumb" style={{ width: 72, height: 52, borderRadius: 10 }} src={w.thumbnail_url || '/images/class.jpg'} alt="" />
                        <span style={{ fontWeight: 400 }}>{w.title}</span>
                      </div>
                    </td>
                    <td>{w.level}</td>
                    <td>{w.duration_min} min</td>
                    <td>{STATUS[w.status]}</td>
                    <td>
                      <div className="inline-form" style={{ justifyContent: 'flex-end' }}>
                        <Link href={`/admin/workouts/${w.id}`} className="btn btn-ghost btn-sm">
                          Edit
                        </Link>
                        {isOwner && (
                          <form action={deleteWorkout}>
                            <input type="hidden" name="id" value={w.id} />
                            <button className="btn btn-ghost btn-sm">Delete</button>
                          </form>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="empty">No workouts yet. Add the first one above.</p>
        )}
      </section>
    </>
  );
}

import Link from 'next/link';
import { notFound } from 'next/navigation';
import { requireStaff } from '@/lib/auth';
import WorkoutForm from '@/components/WorkoutForm';
import { updateWorkout } from '../../actions';

export const dynamic = 'force-dynamic';

export default async function EditWorkout({ params }) {
  const { id } = await params;
  const { supabase, profile } = await requireStaff();
  const { data: workout } = await supabase.from('workouts').select('*').eq('id', id).maybeSingle();
  if (!workout) notFound();
  const isOwner = profile.role === 'owner';

  return (
    <>
      <Link href="/admin/workouts" className="link" style={{ alignSelf: 'flex-start' }}>
        Back to the library
      </Link>
      <div className="page-head">
        <h1 className="page-title">Edit workout</h1>
      </div>
      <section className="panel">
        {!isOwner && workout.status === 'approved' && (
          <p className="alert" style={{ marginBottom: 18 }}>
            This workout is live. Saving changes sends it back to the owner for approval.
          </p>
        )}
        <WorkoutForm action={updateWorkout} workout={workout} isOwner={isOwner} submitLabel="Save changes" />
      </section>
    </>
  );
}

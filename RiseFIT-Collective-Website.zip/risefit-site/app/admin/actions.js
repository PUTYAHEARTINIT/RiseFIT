'use server';

import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { requireStaff } from '@/lib/auth';

const s = (fd, k) => String(fd.get(k) || '').trim();

// "Goblet squat | 4 × 10" per line → [{ name, sets }]
function parseExercises(text) {
  return String(text || '')
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      const [name, ...rest] = line.split('|');
      return { name: name.trim(), sets: rest.join('|').trim() };
    });
}

// Converts a New York wall-clock date + time into a UTC ISO string.
function nyToIso(date, time) {
  const guess = new Date(`${date}T${time}:00Z`);
  const ny = new Date(guess.toLocaleString('en-US', { timeZone: 'America/New_York' }));
  const utc = new Date(guess.toLocaleString('en-US', { timeZone: 'UTC' }));
  return new Date(guess.getTime() + (utc - ny)).toISOString();
}

function refreshAdmin() {
  revalidatePath('/admin', 'layout');
}

/* ---------- Workouts and approvals ---------- */

function workoutFromForm(fd) {
  return {
    title: s(fd, 'title'),
    description: s(fd, 'description') || null,
    level: s(fd, 'level') || 'All levels',
    focus: s(fd, 'focus') || null,
    duration_min: Number(fd.get('duration_min') || 30),
    video_url: s(fd, 'video_url') || null,
    thumbnail_url: s(fd, 'thumbnail_url') || null,
    exercises: parseExercises(fd.get('exercises')),
  };
}

export async function createWorkout(fd) {
  const { supabase, user, profile } = await requireStaff();
  const publishNow = profile.role === 'owner' && fd.get('publish') === 'on';
  await supabase.from('workouts').insert({
    ...workoutFromForm(fd),
    created_by: user.id,
    status: publishNow ? 'approved' : 'pending',
  });
  refreshAdmin();
  redirect(publishNow ? '/admin/workouts' : '/admin/approvals');
}

export async function updateWorkout(fd) {
  const { supabase } = await requireStaff();
  await supabase.from('workouts').update(workoutFromForm(fd)).eq('id', fd.get('id'));
  refreshAdmin();
  redirect('/admin/workouts');
}

export async function approveWorkout(fd) {
  const { supabase, profile } = await requireStaff();
  if (profile.role !== 'owner') return;
  await supabase.from('workouts').update({ status: 'approved', review_note: null }).eq('id', fd.get('id'));
  refreshAdmin();
}

export async function requestChanges(fd) {
  const { supabase, profile } = await requireStaff();
  if (profile.role !== 'owner') return;
  await supabase
    .from('workouts')
    .update({ status: 'changes', review_note: s(fd, 'review_note') || 'Please revise and resubmit.' })
    .eq('id', fd.get('id'));
  refreshAdmin();
}

export async function resubmitWorkout(fd) {
  const { supabase } = await requireStaff();
  await supabase.from('workouts').update({ status: 'pending' }).eq('id', fd.get('id'));
  refreshAdmin();
}

export async function deleteWorkout(fd) {
  const { supabase, profile } = await requireStaff();
  if (profile.role !== 'owner') return;
  await supabase.from('workouts').delete().eq('id', fd.get('id'));
  refreshAdmin();
}

/* ---------- Schedule ---------- */

export async function createSessions(fd) {
  const { supabase } = await requireStaff();
  const date = s(fd, 'date');
  const time = s(fd, 'time');
  if (!date || !time) return;
  const weeks = Math.max(1, Math.min(12, Number(fd.get('repeat') || 1)));
  const first = new Date(nyToIso(date, time));
  const rows = Array.from({ length: weeks }, (_, i) => {
    const d = new Date(first);
    d.setUTCDate(d.getUTCDate() + 7 * i);
    // Recompute through New York time so daylight-saving changes keep the same wall-clock time.
    const local = d.toLocaleDateString('en-CA', { timeZone: 'America/New_York' });
    return {
      title: s(fd, 'title') || 'Session',
      kind: s(fd, 'kind') || 'one_on_one',
      starts_at: nyToIso(local, time),
      duration_min: Number(fd.get('duration_min') || 60),
      location: s(fd, 'location') || null,
      capacity: Math.max(1, Number(fd.get('capacity') || 1)),
    };
  });
  await supabase.from('sessions').insert(rows);
  refreshAdmin();
}

export async function deleteSession(fd) {
  const { supabase } = await requireStaff();
  await supabase.from('sessions').delete().eq('id', fd.get('id'));
  refreshAdmin();
}

/* ---------- Clients ---------- */

export async function assignWorkout(fd) {
  const { supabase } = await requireStaff();
  const workout_id = s(fd, 'workout_id');
  if (!workout_id) return;
  await supabase.from('assignments').insert({
    client_id: fd.get('client_id'),
    workout_id,
    scheduled_for: s(fd, 'scheduled_for') || new Date().toLocaleDateString('en-CA', { timeZone: 'America/New_York' }),
  });
  revalidatePath(`/admin/clients/${fd.get('client_id')}`);
}

export async function removeAssignment(fd) {
  const { supabase } = await requireStaff();
  await supabase.from('assignments').delete().eq('id', fd.get('id'));
  revalidatePath(`/admin/clients/${fd.get('client_id')}`);
}

export async function updateClient(fd) {
  const { supabase, profile } = await requireStaff();
  const changes = {
    coach_note: s(fd, 'coach_note') || null,
    membership: s(fd, 'membership') || null,
  };
  if (profile.role === 'owner' && fd.get('role')) changes.role = s(fd, 'role');
  await supabase.from('profiles').update(changes).eq('id', fd.get('client_id'));
  revalidatePath(`/admin/clients/${fd.get('client_id')}`);
  revalidatePath('/admin/clients');
}

/* ---------- Enrollments ---------- */

export async function setEnrollmentStatus(fd) {
  const { supabase } = await requireStaff();
  await supabase.from('enrollments').update({ status: s(fd, 'status') }).eq('id', fd.get('id'));
  refreshAdmin();
}

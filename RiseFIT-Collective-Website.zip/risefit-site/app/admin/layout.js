import AppShell from '@/components/AppShell';
import SetupNotice from '@/components/SetupNotice';
import { isConfigured } from '@/lib/supabase/server';
import { requireStaff } from '@/lib/auth';
import { initials } from '@/lib/format';

export const metadata = { title: 'Owner studio' };

export default async function AdminLayout({ children }) {
  if (!isConfigured()) return <SetupNotice />;
  const { supabase, profile } = await requireStaff();

  const [{ count: pending }, { count: fresh }] = await Promise.all([
    supabase.from('workouts').select('id', { count: 'exact', head: true }).eq('status', 'pending'),
    supabase.from('enrollments').select('id', { count: 'exact', head: true }).eq('status', 'new'),
  ]);

  const links = [
    { href: '/admin', label: 'Overview' },
    { href: '/admin/approvals', label: 'Approvals', count: pending || 0 },
    { href: '/admin/workouts', label: 'Workout library' },
    { href: '/admin/schedule', label: 'Schedule' },
    { href: '/admin/clients', label: 'Clients' },
    { href: '/admin/enrollments', label: 'Enrollments', count: fresh || 0 },
  ];

  return (
    <AppShell
      links={links}
      label={profile.role === 'owner' ? 'Owner studio' : 'Trainer studio'}
      name={profile.full_name}
      roleLabel={profile.role === 'owner' ? 'Owner' : 'Trainer'}
      initials={initials(profile.full_name)}
      switchLink={{ href: '/portal', label: 'Client view' }}
    >
      {children}
    </AppShell>
  );
}

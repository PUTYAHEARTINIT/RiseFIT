import Link from 'next/link';
import { requireStaff } from '@/lib/auth';
import { fmtDate, initials } from '@/lib/format';

export const dynamic = 'force-dynamic';

export default async function Clients() {
  const { supabase } = await requireStaff();
  const [{ data: people }, { data: logs }] = await Promise.all([
    supabase.from('profiles').select('*').order('full_name'),
    supabase
      .from('workout_logs')
      .select('client_id, created_at')
      .gte('created_at', new Date(Date.now() - 90 * 864e5).toISOString()),
  ]);

  const last = {};
  const count = {};
  (logs || []).forEach((l) => {
    count[l.client_id] = (count[l.client_id] || 0) + 1;
    if (!last[l.client_id] || l.created_at > last[l.client_id]) last[l.client_id] = l.created_at;
  });

  return (
    <>
      <div className="page-head">
        <div>
          <div className="page-date">{people?.filter((p) => p.role === 'client').length || 0} clients</div>
          <h1 className="page-title">Clients</h1>
        </div>
      </div>
      <section className="panel">
        {people?.length ? (
          <div className="table-wrap">
            <table className="table">
              <thead>
                <tr>
                  <th scope="col">Name</th>
                  <th scope="col">Membership</th>
                  <th scope="col">Workouts, last 90 days</th>
                  <th scope="col">Last workout</th>
                  <th scope="col">Role</th>
                </tr>
              </thead>
              <tbody>
                {people.map((p) => (
                  <tr key={p.id}>
                    <td>
                      <Link href={`/admin/clients/${p.id}`} style={{ display: 'flex', gap: 12, alignItems: 'center', textDecoration: 'none' }}>
                        <span className="avatar" style={{ width: 36, height: 36, fontSize: 15 }} aria-hidden="true">
                          {initials(p.full_name)}
                        </span>
                        <span>
                          <span style={{ fontWeight: 400, display: 'block' }}>{p.full_name}</span>
                          <span className="meta">{p.email}</span>
                        </span>
                      </Link>
                    </td>
                    <td>{p.membership || ''}</td>
                    <td>{count[p.id] || 0}</td>
                    <td>{last[p.id] ? fmtDate(last[p.id], { month: 'short', day: 'numeric' }) : 'None yet'}</td>
                    <td>{p.role === 'client' ? 'Client' : p.role === 'owner' ? 'Owner' : 'Trainer'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="empty">No accounts yet. Clients appear here once they create an account on the site.</p>
        )}
      </section>
    </>
  );
}

import Link from 'next/link';
import { notFound } from 'next/navigation';
import { requireStaff } from '@/lib/auth';
import { fmtDate, fmtTime } from '@/lib/format';
import { assignWorkout, removeAssignment, updateClient } from '../../actions';

export const dynamic = 'force-dynamic';

export default async function ClientDetail({ params }) {
  const { id } = await params;
  const { supabase, profile: me } = await requireStaff();

  const [{ data: client }, { data: workouts }, { data: assignments }, { data: logs }, { data: goals }, { data: bookings }] = await Promise.all([
    supabase.from('profiles').select('*').eq('id', id).maybeSingle(),
    supabase.from('workouts').select('id, title').eq('status', 'approved').order('title'),
    supabase.from('assignments').select('*, workout:workouts(title)').eq('client_id', id).order('scheduled_for', { ascending: false }).limit(12),
    supabase.from('workout_logs').select('*, workout:workouts(title, exercises)').eq('client_id', id).order('created_at', { ascending: false }).limit(10),
    supabase.from('goals').select('*').eq('client_id', id).order('created_at'),
    supabase.from('bookings').select('id, status, session:sessions(title, starts_at)').eq('client_id', id).eq('status', 'booked'),
  ]);
  if (!client) notFound();

  const today = new Date().toLocaleDateString('en-CA', { timeZone: 'America/New_York' });
  const upcoming = (bookings || []).filter((b) => b.session && new Date(b.session.starts_at) > new Date());

  return (
    <>
      <Link href="/admin/clients" className="link" style={{ alignSelf: 'flex-start' }}>
        All clients
      </Link>
      <div className="page-head">
        <div>
          <div className="page-date">
            {client.email}
            {client.phone ? `, ${client.phone}` : ''}
          </div>
          <h1 className="page-title">{client.full_name}</h1>
        </div>
      </div>

      {client.injuries && (
        <p className="alert">
          <strong style={{ fontWeight: 500 }}>Injuries or limitations:</strong> {client.injuries}
        </p>
      )}

      <div className="cols">
        <div className="stack" style={{ gap: 24 }}>
          <section className="panel">
            <h2 className="panel-title" style={{ marginBottom: 16 }}>
              Assign a workout
            </h2>
            {workouts?.length ? (
              <form action={assignWorkout} className="inline-form">
                <input type="hidden" name="client_id" value={client.id} />
                <select name="workout_id" aria-label="Workout" required style={{ flex: '1 1 240px' }}>
                  {workouts.map((w) => (
                    <option key={w.id} value={w.id}>
                      {w.title}
                    </option>
                  ))}
                </select>
                <input type="date" name="scheduled_for" defaultValue={today} aria-label="Date" />
                <button className="btn btn-sm">Assign</button>
              </form>
            ) : (
              <p className="empty">
                Approve a workout first, then you can assign it. <Link href="/admin/workouts" className="link">Go to the library</Link>
              </p>
            )}
            {assignments?.length > 0 && (
              <ul className="rows" style={{ marginTop: 16 }}>
                {assignments.map((a) => (
                  <li key={a.id}>
                    <div className="row-main">
                      <strong>{a.workout?.title}</strong>
                      <span className="meta">
                        For {fmtDate(a.scheduled_for + 'T12:00:00', { weekday: 'short', month: 'short', day: 'numeric' })}
                      </span>
                    </div>
                    {a.completed_at ? <span className="badge badge-ink">Done</span> : <span className="badge">Assigned</span>}
                    {!a.completed_at && (
                      <form action={removeAssignment}>
                        <input type="hidden" name="id" value={a.id} />
                        <input type="hidden" name="client_id" value={client.id} />
                        <button className="btn btn-ghost btn-sm">Remove</button>
                      </form>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section className="panel">
            <h2 className="panel-title" style={{ marginBottom: 12 }}>
              Recent workouts
            </h2>
            {logs?.length ? (
              <ul className="rows">
                {logs.map((l) => {
                  const total = Array.isArray(l.workout?.exercises) ? l.workout.exercises.length : 0;
                  return (
                    <li key={l.id}>
                      <div className="row-main">
                        <strong>{l.workout?.title || 'Workout'}</strong>
                        <span className="meta">
                          {fmtDate(l.created_at, { weekday: 'short', month: 'short', day: 'numeric' })}, {fmtTime(l.created_at)}
                          {total ? `, ${l.completed.length} of ${total} exercises` : ''}
                        </span>
                        {l.notes && <p style={{ marginTop: 6, color: 'var(--graphite)' }}>“{l.notes}”</p>}
                      </div>
                    </li>
                  );
                })}
              </ul>
            ) : (
              <p className="empty">No workouts logged yet.</p>
            )}
          </section>
        </div>

        <div className="stack" style={{ gap: 24 }}>
          <section className="panel panel-mist">
            <h2 className="panel-title" style={{ marginBottom: 16 }}>
              Coaching
            </h2>
            <form action={updateClient} className="stack">
              <input type="hidden" name="client_id" value={client.id} />
              <label className="field">
                Note on their dashboard
                <textarea name="coach_note" defaultValue={client.coach_note || ''} placeholder="Great depth on your squats this week…" />
              </label>
              <label className="field">
                Membership
                <select name="membership" defaultValue={client.membership || 'Collective'}>
                  <option>Remote</option>
                  <option>Collective</option>
                  <option>Elite</option>
                  <option>Paused</option>
                </select>
              </label>
              {me.role === 'owner' && (
                <label className="field">
                  Account role
                  <select name="role" defaultValue={client.role}>
                    <option value="client">Client</option>
                    <option value="trainer">Trainer</option>
                    <option value="owner">Owner</option>
                  </select>
                </label>
              )}
              <button className="btn" style={{ alignSelf: 'flex-start' }}>
                Save
              </button>
            </form>
          </section>

          <section className="panel">
            <h2 className="panel-title" style={{ marginBottom: 12 }}>
              Goals
            </h2>
            {goals?.length ? (
              goals.map((g) => {
                const pct = Math.max(0, Math.min(100, (Number(g.current_value) / Number(g.target_value || 1)) * 100));
                return (
                  <div className="goal" key={g.id}>
                    <div className="goal-top">
                      <strong>{g.title}</strong>
                      <span className="meta">
                        {g.current_value} of {g.target_value} {g.unit || ''}
                      </span>
                    </div>
                    <div className="bar">
                      <span style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                );
              })
            ) : (
              <p className="empty">No goals set yet.</p>
            )}
          </section>

          <section className="panel">
            <h2 className="panel-title" style={{ marginBottom: 12 }}>
              Booked
            </h2>
            {upcoming.length ? (
              <ul className="rows">
                {upcoming.map((b) => (
                  <li key={b.id}>
                    <div className="row-main">
                      <strong>{b.session.title}</strong>
                      <span className="meta">
                        {fmtDate(b.session.starts_at, { weekday: 'short', month: 'short', day: 'numeric' })}, {fmtTime(b.session.starts_at)}
                      </span>
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="empty">Nothing booked.</p>
            )}
          </section>
        </div>
      </div>
    </>
  );
}

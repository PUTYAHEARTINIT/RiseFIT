import { requireStaff } from '@/lib/auth';
import ApprovalRow from '@/components/ApprovalRow';

export const dynamic = 'force-dynamic';

export default async function Approvals() {
  const { supabase, profile } = await requireStaff();
  const { data: queue } = await supabase
    .from('workouts')
    .select('*, author:profiles!workouts_created_by_fkey(full_name)')
    .in('status', ['pending', 'changes'])
    .order('created_at');

  const pending = (queue || []).filter((w) => w.status === 'pending');
  const changes = (queue || []).filter((w) => w.status === 'changes');
  const isOwner = profile.role === 'owner';

  return (
    <>
      <div className="page-head">
        <div>
          <div className="page-date">Nothing reaches clients until it’s approved</div>
          <h1 className="page-title">Approvals</h1>
        </div>
      </div>

      <section className="panel">
        <h2 className="panel-title" style={{ marginBottom: 12 }}>
          Waiting for review
        </h2>
        {pending.length ? (
          <ul className="rows">
            {pending.map((w) => (
              <ApprovalRow key={w.id} w={w} isOwner={isOwner} />
            ))}
          </ul>
        ) : (
          <p className="empty">The queue is empty.</p>
        )}
      </section>

      {changes.length > 0 && (
        <section className="panel">
          <h2 className="panel-title" style={{ marginBottom: 12 }}>
            Sent back for changes
          </h2>
          <ul className="rows">
            {changes.map((w) => (
              <ApprovalRow key={w.id} w={w} isOwner={isOwner} />
            ))}
          </ul>
        </section>
      )}
    </>
  );
}

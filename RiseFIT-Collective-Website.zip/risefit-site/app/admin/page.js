import Link from 'next/link';
import { requireStaff, firstName } from '@/lib/auth';
import { fmtLong, fmtTime, fmtDate, KIND_LABEL } from '@/lib/format';
import ApprovalRow from '@/components/ApprovalRow';

export const dynamic = 'force-dynamic';

const TZ = 'America/New_York';
const nyDay = (d) => new Date(d).toLocaleDateString('en-CA', { timeZone: TZ });

export default async function AdminHome() {
  const { supabase, profile } = await requireStaff();
  const now = new Date();
  const weekAhead = new Date(now.getTime() + 7 * 864e5).toISOString();
  const twoWeeksAgo = new Date(now.getTime() - 14 * 864e5).toISOString();

  const [{ data: clients }, { data: pending }, { data: sessions }, { data: enrollments }, { data: logs }] = await Promise.all([
    supabase.from('profiles').select('id, full_name, created_at').eq('role', 'client'),
    supabase
      .from('workouts')
      .select('*, author:profiles!workouts_created_by_fkey(full_name)')
      .eq('status', 'pending')
      .order('created_at')
      .limit(3),
    supabase
      .from('sessions')
      .select('*, bookings(id, status, client:profiles(full_name))')
      .gte('starts_at', new Date(now.getTime() - 3 * 3600e3).toISOString())
      .lte('starts_at', weekAhead)
      .order('starts_at'),
    supabase.from('enrollments').select('*').eq('status', 'new').order('created_at', { ascending: false }).limit(4),
    supabase.from('workout_logs').select('client_id, created_at').gte('created_at', twoWeeksAgo),
  ]);

  const today = nyDay(now);
  const todays = (sessions || []).filter((s) => nyDay(s.starts_at) === today);
  const booked = (s) => (s.bookings || []).filter((b) => b.status === 'booked');
  const spotsBooked = (sessions || []).reduce((n, s) => n + booked(s).length, 0);

  const lastLog = {};
  (logs || []).forEach((l) => {
    if (!lastLog[l.client_id] || l.created_at > lastLog[l.client_id]) lastLog[l.client_id] = l.created_at;
  });
  const weekAgo = new Date(now.getTime() - 7 * 864e5).toISOString();
  const quiet = (clients || [])
    .filter((c) => c.created_at < weekAgo && (!lastLog[c.id] || lastLog[c.id] < weekAgo))
    .slice(0, 5);
  const isOwner = profile.role === 'owner';

  return (
    <>
      <div className="page-head">
        <div>
          <div className="page-date">{fmtLong(now)}</div>
          <h1 className="page-title">Welcome back, {firstName(profile)}</h1>
        </div>
        <div className="btn-row">
          <Link href="/admin/schedule" className="btn btn-ghost">
            Add sessions
          </Link>
          <Link href="/admin/workouts#new" className="btn">
            Add a workout
          </Link>
        </div>
      </div>

      <div className="stats">
        <div className="stat">
          <div className="stat-label">Clients</div>
          <div className="stat-value">{clients?.length || 0}</div>
        </div>
        <div className="stat">
          <div className="stat-label">Spots booked, next 7 days</div>
          <div className="stat-value">{spotsBooked}</div>
          <div className="stat-note">{sessions?.length || 0} sessions on the calendar</div>
        </div>
        <div className="stat">
          <div className="stat-label">New enrollment requests</div>
          <div className="stat-value">{enrollments?.length || 0}</div>
        </div>
        <div className="stat stat-accent">
          <div className="stat-label">Waiting for your approval</div>
          <div className="stat-value">{pending?.length || 0}</div>
        </div>
      </div>

      <section className="panel">
        <div className="panel-head">
          <h2 className="panel-title">Remote workout approvals</h2>
          <Link href="/admin/approvals" className="link">
            Open the queue
          </Link>
        </div>
        {pending?.length ? (
          <ul className="rows">
            {pending.map((w) => (
              <ApprovalRow key={w.id} w={w} isOwner={isOwner} compact />
            ))}
          </ul>
        ) : (
          <p className="empty">You’re all caught up. New trainer uploads will appear here before clients see them.</p>
        )}
      </section>

      <div className="cols">
        <section className="panel">
          <div className="panel-head">
            <h2 className="panel-title">Today</h2>
            <Link href="/admin/schedule" className="link">
              Full schedule
            </Link>
          </div>
          {todays.length ? (
            <ul className="rows">
              {todays.map((s) => (
                <li key={s.id}>
                  <span style={{ fontFamily: 'var(--serif)', fontSize: 28, minWidth: 110 }}>{fmtTime(s.starts_at)}</span>
                  <div className="row-main">
                    <strong>{s.title}</strong>
                    <span className="meta">
                      {KIND_LABEL[s.kind]}
                      {s.location ? `, ${s.location}` : ''}
                      {': '}
                      {booked(s).length ? booked(s).map((b) => b.client?.full_name).join(', ') : 'no bookings yet'}
                    </span>
                  </div>
                  <span className="badge badge-line">
                    {booked(s).length} of {s.capacity}
                  </span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="empty">Nothing on the calendar today.</p>
          )}
        </section>

        <div className="stack" style={{ gap: 24 }}>
          <section className="panel">
            <h2 className="panel-title" style={{ marginBottom: 12 }}>
              Needs attention
            </h2>
            {quiet.length ? (
              <ul className="rows">
                {quiet.map((c) => (
                  <li key={c.id}>
                    <div className="row-main">
                      <Link href={`/admin/clients/${c.id}`} style={{ textDecoration: 'none' }}>
                        <strong>{c.full_name}</strong>
                      </Link>
                      <span className="meta">
                        {lastLog[c.id] ? `Last workout ${fmtDate(lastLog[c.id], { month: 'short', day: 'numeric' })}` : 'No workouts logged in 2 weeks'}
                      </span>
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="empty">Every client has logged a workout this week.</p>
            )}
          </section>

          <section className="panel panel-ink">
            <div className="panel-head">
              <h2 className="panel-title">New enrollments</h2>
              <Link href="/admin/enrollments" className="link">
                Review
              </Link>
            </div>
            {enrollments?.length ? (
              <ul className="rows">
                {enrollments.map((e) => (
                  <li key={e.id}>
                    <div className="row-main">
                      <strong>
                        {e.first_name} {e.last_name}
                      </strong>
                      <span style={{ color: '#c9c4d1', fontSize: 15 }}>
                        {e.program}, {e.goal}
                      </span>
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <p style={{ color: '#c9c4d1' }}>No new requests. Website sign-ups land here.</p>
            )}
          </section>
        </div>
      </div>
    </>
  );
}

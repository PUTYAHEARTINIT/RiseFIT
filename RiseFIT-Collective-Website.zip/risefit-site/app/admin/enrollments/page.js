import { requireStaff } from '@/lib/auth';
import { fmtDate } from '@/lib/format';
import { setEnrollmentStatus } from '../actions';

export const dynamic = 'force-dynamic';

const LABEL = { new: 'New', contacted: 'Contacted', enrolled: 'Enrolled', archived: 'Archived' };

export default async function Enrollments({ searchParams }) {
  const params = await searchParams;
  const show = params?.show === 'all' ? 'all' : 'open';
  const { supabase } = await requireStaff();
  let query = supabase.from('enrollments').select('*').order('created_at', { ascending: false });
  if (show === 'open') query = query.in('status', ['new', 'contacted']);
  const { data: rows } = await query;

  return (
    <>
      <div className="page-head">
        <div>
          <div className="page-date">Requests from the website form</div>
          <h1 className="page-title">Enrollments</h1>
        </div>
        <div className="choice-row">
          <a href="/admin/enrollments" className="choice" aria-pressed={show === 'open'} style={{ display: 'inline-flex', alignItems: 'center', textDecoration: 'none' }}>
            Open
          </a>
          <a href="/admin/enrollments?show=all" className="choice" aria-pressed={show === 'all'} style={{ display: 'inline-flex', alignItems: 'center', textDecoration: 'none' }}>
            All
          </a>
        </div>
      </div>

      <section className="panel">
        {rows?.length ? (
          <div className="table-wrap">
            <table className="table">
              <thead>
                <tr>
                  <th scope="col">Person</th>
                  <th scope="col">Interested in</th>
                  <th scope="col">Notes</th>
                  <th scope="col">Received</th>
                  <th scope="col">Status</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((e) => (
                  <tr key={e.id}>
                    <td>
                      <span style={{ fontWeight: 400, display: 'block' }}>
                        {e.first_name} {e.last_name}
                      </span>
                      <a href={`mailto:${e.email}`} className="link meta">
                        {e.email}
                      </a>
                      {e.phone && (
                        <span className="meta" style={{ display: 'block' }}>
                          {e.phone}
                          {e.sms_consent ? ', OK to text' : ''}
                        </span>
                      )}
                    </td>
                    <td>
                      {e.program}
                      <span className="meta" style={{ display: 'block' }}>
                        {e.goal}
                      </span>
                    </td>
                    <td style={{ maxWidth: 280, color: 'var(--graphite)' }}>{e.notes}</td>
                    <td>{fmtDate(e.created_at, { month: 'short', day: 'numeric' })}</td>
                    <td>
                      <form action={setEnrollmentStatus} className="inline-form">
                        <input type="hidden" name="id" value={e.id} />
                        <select name="status" defaultValue={e.status} aria-label="Status">
                          {Object.entries(LABEL).map(([v, l]) => (
                            <option key={v} value={v}>
                              {l}
                            </option>
                          ))}
                        </select>
                        <button className="btn btn-ghost btn-sm">Update</button>
                      </form>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="empty">No open requests. New website enrollments will appear here.</p>
        )}
      </section>
    </>
  );
}

import { requireStaff } from '@/lib/auth';
import { fmtDay, fmtDayNum, fmtTime, fmtDate, KIND_LABEL } from '@/lib/format';
import { createSessions, deleteSession } from '../actions';

export const dynamic = 'force-dynamic';

export default async function Schedule() {
  const { supabase } = await requireStaff();
  const { data: sessions } = await supabase
    .from('sessions')
    .select('*, bookings(id, status, client:profiles(full_name))')
    .gte('starts_at', new Date(Date.now() - 3 * 3600e3).toISOString())
    .order('starts_at')
    .limit(120);

  const today = new Date().toLocaleDateString('en-CA', { timeZone: 'America/New_York' });

  // Group by week label for easier scanning.
  const groups = [];
  (sessions || []).forEach((s) => {
    const label = fmtDate(s.starts_at, { weekday: 'long', month: 'long', day: 'numeric' });
    const last = groups.at(-1);
    if (last && last.label === label) last.items.push(s);
    else groups.push({ label, items: [s] });
  });

  return (
    <>
      <div className="page-head">
        <div>
          <div className="page-date">Clients can book anything you add here</div>
          <h1 className="page-title">Schedule</h1>
        </div>
      </div>

      <details className="drawer" open={!sessions?.length}>
        <summary>Add sessions</summary>
        <form action={createSessions} className="stack">
          <div className="grid-2">
            <label className="field">
              Title
              <input name="title" placeholder="1:1 strength session" required />
            </label>
            <label className="field">
              Type
              <select name="kind" defaultValue="one_on_one">
                <option value="one_on_one">1:1 session</option>
                <option value="group">Group class</option>
                <option value="check_in">Check-in call</option>
              </select>
            </label>
          </div>
          <div className="grid-2">
            <label className="field">
              Date
              <input name="date" type="date" min={today} defaultValue={today} required />
            </label>
            <label className="field">
              Start time (Eastern)
              <input name="time" type="time" defaultValue="18:00" required />
            </label>
            <label className="field">
              Length in minutes
              <input name="duration_min" type="number" min="15" step="5" defaultValue={60} />
            </label>
          </div>
          <div className="grid-2">
            <label className="field">
              Location
              <input name="location" placeholder="Studio, park, or video call" />
            </label>
            <label className="field">
              Spots
              <input name="capacity" type="number" min="1" defaultValue={1} />
            </label>
            <label className="field">
              Repeat weekly for
              <select name="repeat" defaultValue="1">
                <option value="1">Just this once</option>
                <option value="4">4 weeks</option>
                <option value="8">8 weeks</option>
                <option value="12">12 weeks</option>
              </select>
            </label>
          </div>
          <button className="btn" style={{ alignSelf: 'flex-start' }}>
            Add to schedule
          </button>
        </form>
      </details>

      {groups.length ? (
        groups.map((g) => (
          <section key={g.label} className="panel">
            <h2 className="panel-title" style={{ fontSize: 28, marginBottom: 8 }}>
              {g.label}
            </h2>
            <ul className="rows">
              {g.items.map((s) => {
                const booked = (s.bookings || []).filter((b) => b.status === 'booked');
                return (
                  <li key={s.id}>
                    <div className="date-chip">
                      <small>{fmtDay(s.starts_at)}</small>
                      <strong>{fmtDayNum(s.starts_at)}</strong>
                    </div>
                    <div className="row-main">
                      <strong>
                        {fmtTime(s.starts_at)}, {s.title}
                      </strong>
                      <span className="meta">
                        {KIND_LABEL[s.kind]}, {s.duration_min} min{s.location ? `, ${s.location}` : ''}
                        {booked.length ? `. Booked: ${booked.map((b) => b.client?.full_name).join(', ')}` : ''}
                      </span>
                    </div>
                    <span className={`badge ${booked.length >= s.capacity ? 'badge-ink' : 'badge-line'}`}>
                      {booked.length} of {s.capacity}
                    </span>
                    <form action={deleteSession}>
                      <input type="hidden" name="id" value={s.id} />
                      <button className="btn btn-ghost btn-sm">Remove</button>
                    </form>
                  </li>
                );
              })}
            </ul>
          </section>
        ))
      ) : (
        <p className="empty">No upcoming sessions. Add your available times above so clients can book.</p>
      )}
    </>
  );
}

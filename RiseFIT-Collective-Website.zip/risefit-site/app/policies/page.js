import Link from 'next/link';
import SiteHeader from '@/components/SiteHeader';

export const metadata = { title: 'Policies and waiver' };

export default function Policies() {
  return (
    <>
      <SiteHeader />
      <main className="section">
        <div className="wrap" style={{ maxWidth: 820 }}>
          <h1 className="section-title" style={{ marginBottom: 40 }}>
            Policies and waiver
          </h1>
          <div className="stack" style={{ color: 'var(--graphite)' }}>
            <h2 style={{ fontSize: 36 }}>Cancellations</h2>
            <p>
              You can cancel a booking from your portal up to 24 hours before it starts. For anything later, message
              your coach. [Add the no-show policy here.]
            </p>
            <h2 style={{ fontSize: 36, marginTop: 24 }}>Liability waiver</h2>
            <p>[Paste the full waiver text here, reviewed by your lawyer or insurer.]</p>
            <h2 style={{ fontSize: 36, marginTop: 24 }}>Privacy</h2>
            <p>
              Your progress, goals and health notes are visible only to you and your coach. We never sell your
              information. [Add your full privacy policy here.]
            </p>
            <p style={{ marginTop: 24 }}>
              <Link href="/" className="link">
                Back to home
              </Link>
            </p>
          </div>
        </div>
      </main>
    </>
  );
}

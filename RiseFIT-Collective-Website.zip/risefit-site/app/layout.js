import '@fontsource/cormorant-garamond/400.css';
import '@fontsource/cormorant-garamond/500.css';
import '@fontsource/cormorant-garamond/600.css';
import '@fontsource/cormorant-garamond/400-italic.css';
import '@fontsource/jost/300.css';
import '@fontsource/jost/400.css';
import '@fontsource/jost/500.css';
import './globals.css';

export const metadata = {
  title: {
    default: 'RiseFIT Collective',
    template: '%s · RiseFIT Collective',
  },
  description:
    'Coaching, community workouts and remote training to help you get stronger, feel at home in your body and keep showing up.',
  icons: { icon: '/images/logo-black.png' },
};

export const viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#ffffff',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}

import Link from 'next/link';
import { requireUser, firstName } from '@/lib/auth';
import { fmtLong, fmtDay, fmtDayNum, fmtTime, KIND_LABEL, fmtDate } from '@/lib/format';
import WorkoutLogger from '@/components/WorkoutLogger';
import Video from '@/components/Video';

export const dynamic = 'force-dynamic';

function nyDate(d) {
  return new Date(d).toLocaleDateString('en-CA', { timeZone: 'America/New_York' });
}

function streak(logs) {
  const days = new Set(logs.map((l) => nyDate(l.created_at)));
  let count = 0;
  const cursor = new Date();
  if (!days.has(nyDate(cursor))) cursor.setDate(cursor.getDate() - 1);
  while (days.has(nyDate(cursor))) {
    count += 1;
    cursor.setDate(cursor.getDate() - 1);
  }
  return count;
}

function greeting() {
  const h = Number(new Date().toLocaleString('en-US', { timeZone: 'America/New_York', hour: 'numeric', hour12: false }));
  if (h < 12) return 'Good morning';
  if (h < 17) return 'Good afternoon';
  return 'Good evening';
}

export default async function PortalHome() {
  const { supabase, user, profile } = await requireUser();
  const since = new Date(Date.now() - 62 * 864e5).toISOString();

  const [{ data: assignment }, { data: logs }, { data: goals }, { data: bookings }] = await Promise.all([
    supabase
      .from('assignments')
      .select('id, scheduled_for, workout:workouts(*)')
      .eq('client_id', user.id)
      .is('completed_at', null)
      .order('scheduled_for', { ascending: true })
      .limit(1)
      .maybeSingle(),
    supabase.from('workout_logs').select('id, created_at').eq('client_id', user.id).gte('created_at', since),
    supabase.from('goals').select('*').eq('client_id', user.id).order('created_at').limit(4),
    supabase
      .from('bookings')
      .select('id, status, session:sessions(*)')
      .eq('client_id', user.id)
      .eq('status', 'booked'),
  ]);

  const upcoming = (bookings || [])
    .filter((b) => b.session && new Date(b.session.starts_at) > new Date())
    .sort((a, b) => new Date(a.session.starts_at) - new Date(b.session.starts_at));
  const next = upcoming[0]?.session;
  const monthKey = nyDate(new Date()).slice(0, 7);
  const thisMonth = (logs || []).filter((l) => nyDate(l.created_at).startsWith(monthKey)).length;
  const workout = assignment?.workout;

  return (
    <>
      <div className="page-head">
        <div>
          <div className="page-date">{fmtLong(new Date())}</div>
          <h1 className="page-title">
            {greeting()}, {firstName(profile)}
          </h1>
        </div>
        <div className="btn-row">
          <Link href="/portal/workouts" className="btn btn-ghost">
            Browse workouts
          </Link>
          <Link href="/portal/book" className="btn">
            Book a session
          </Link>
        </div>
      </div>

      <div className="stats">
        <div className="stat">
          <div className="stat-label">Current streak</div>
          <div className="stat-value">
            {streak(logs || [])} <small>days</small>
          </div>
        </div>
        <div className="stat">
          <div className="stat-label">Workouts this month</div>
          <div className="stat-value">{thisMonth}</div>
        </div>
        <div className="stat">
          <div className="stat-label">Next session</div>
          <div className="stat-value" style={{ fontSize: 34, lineHeight: 1.6 }}>
            {next ? `${fmtDay(next.starts_at)} ${fmtTime(next.starts_at)}` : 'None booked'}
          </div>
        </div>
        <div className="stat stat-accent">
          <div className="stat-label">Active goals</div>
          <div className="stat-value">{goals?.length || 0}</div>
        </div>
      </div>

      <div className="cols">
        <section className="panel">
          {workout ? (
            <>
              <Video url={workout.video_url} title={workout.title} />
              <WorkoutLogger
                key={assignment.id}
                workout={workout}
                assignmentId={assignment.id}
                heading={`Assigned for ${fmtDate(assignment.scheduled_for + 'T12:00:00', { weekday: 'long', month: 'short', day: 'numeric' })}`}
              />
            </>
          ) : (
            <div className="stack">
              <h2 className="panel-title">No workout assigned right now</h2>
              <p className="meta">
                Your coach will add your next one here. In the meantime, pick anything from the workout library.
              </p>
              <Link href="/portal/workouts" className="btn" style={{ alignSelf: 'flex-start' }}>
                Open the library
              </Link>
            </div>
          )}
        </section>

        <div className="stack" style={{ gap: 24 }}>
          {profile.coach_note && (
            <section className="panel panel-mist">
              <div className="stat-label">A note from your coach</div>
              <p className="coach-note">“{profile.coach_note}”</p>
            </section>
          )}

          <section className="panel">
            <div className="panel-head">
              <h2 className="panel-title">Goals</h2>
              <Link href="/portal/goals" className="link">
                Manage
              </Link>
            </div>
            {goals?.length ? (
              goals.map((g) => {
                const pct = Math.max(0, Math.min(100, (Number(g.current_value) / Number(g.target_value || 1)) * 100));
                return (
                  <div className="goal" key={g.id}>
                    <div className="goal-top">
                      <strong>{g.title}</strong>
                      <span className="meta">
                        {g.current_value} of {g.target_value} {g.unit || ''}
                      </span>
                    </div>
                    <div className="bar">
                      <span style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                );
              })
            ) : (
              <p className="empty">Set your first goal so you and your coach can track it together.</p>
            )}
          </section>

          <section className="panel">
            <div className="panel-head">
              <h2 className="panel-title">Upcoming</h2>
              <Link href="/portal/book" className="link">
                Book more
              </Link>
            </div>
            {upcoming.length ? (
              <ul className="rows">
                {upcoming.slice(0, 4).map((b) => (
                  <li key={b.id}>
                    <div className="date-chip">
                      <small>{fmtDay(b.session.starts_at)}</small>
                      <strong>{fmtDayNum(b.session.starts_at)}</strong>
                    </div>
                    <div className="row-main">
                      <strong>{b.session.title}</strong>
                      <span className="meta">
                        {fmtTime(b.session.starts_at)}, {b.session.location || KIND_LABEL[b.session.kind]}
                      </span>
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="empty">Nothing booked yet.</p>
            )}
          </section>
        </div>
      </div>
    </>
  );
}

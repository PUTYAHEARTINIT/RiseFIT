'use server';

import { revalidatePath } from 'next/cache';
import { requireUser } from '@/lib/auth';

export async function logWorkout({ workoutId, assignmentId, completed, notes }) {
  const { supabase, user } = await requireUser();
  const { error } = await supabase.from('workout_logs').insert({
    client_id: user.id,
    workout_id: workoutId,
    assignment_id: assignmentId || null,
    completed: completed || [],
    notes: notes || null,
  });
  if (error) return { error: 'Your workout didn’t save. Try again.' };
  if (assignmentId) {
    await supabase.from('assignments').update({ completed_at: new Date().toISOString() }).eq('id', assignmentId).eq('client_id', user.id);
  }
  revalidatePath('/portal');
  return { ok: true };
}

export async function addGoal(formData) {
  const { supabase, user } = await requireUser();
  const title = String(formData.get('title') || '').trim();
  if (!title) return;
  await supabase.from('goals').insert({
    client_id: user.id,
    title,
    current_value: Number(formData.get('current_value') || 0),
    target_value: Number(formData.get('target_value') || 100),
    unit: String(formData.get('unit') || '').trim() || null,
    target_date: formData.get('target_date') || null,
  });
  revalidatePath('/portal/goals');
  revalidatePath('/portal');
}

export async function updateGoal(formData) {
  const { supabase, user } = await requireUser();
  await supabase
    .from('goals')
    .update({ current_value: Number(formData.get('current_value') || 0) })
    .eq('id', formData.get('id'))
    .eq('client_id', user.id);
  revalidatePath('/portal/goals');
  revalidatePath('/portal');
}

export async function deleteGoal(formData) {
  const { supabase, user } = await requireUser();
  await supabase.from('goals').delete().eq('id', formData.get('id')).eq('client_id', user.id);
  revalidatePath('/portal/goals');
  revalidatePath('/portal');
}

export async function bookSession(sessionId) {
  const { supabase } = await requireUser();
  const { error } = await supabase.rpc('book_session', { p_session: sessionId });
  if (error) return { error: error.message };
  revalidatePath('/portal/book');
  revalidatePath('/portal');
  return { ok: true };
}

export async function cancelBooking(formData) {
  const { supabase } = await requireUser();
  const { error } = await supabase.rpc('cancel_booking', { p_booking: formData.get('id') });
  revalidatePath('/portal/book');
  revalidatePath('/portal');
  if (error) return { error: error.message };
  return { ok: true };
}

export async function updateProfile(_prev, formData) {
  const { supabase, user } = await requireUser();
  const { error } = await supabase
    .from('profiles')
    .update({
      full_name: String(formData.get('full_name') || '').trim(),
      phone: String(formData.get('phone') || '').trim(),
      injuries: String(formData.get('injuries') || '').trim(),
    })
    .eq('id', user.id);
  revalidatePath('/portal', 'layout');
  return error ? { error: 'Your changes didn’t save. Try again.' } : { notice: 'Profile saved.' };
}

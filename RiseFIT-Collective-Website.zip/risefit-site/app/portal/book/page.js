import { requireUser } from '@/lib/auth';
import { fmtDay, fmtDayNum, fmtTime, KIND_LABEL } from '@/lib/format';
import BookingPicker from '@/components/BookingPicker';
import CancelButton from '@/components/CancelButton';
import { cancelBooking } from '../actions';

export const dynamic = 'force-dynamic';

export default async function Book() {
  const { supabase, user } = await requireUser();
  const [{ data: sessions }, { data: bookings }] = await Promise.all([
    supabase.rpc('upcoming_sessions', { days_ahead: 14 }),
    supabase.from('bookings').select('id, status, session:sessions(*)').eq('client_id', user.id).eq('status', 'booked'),
  ]);

  const upcoming = (bookings || [])
    .filter((b) => b.session && new Date(b.session.starts_at) > new Date())
    .sort((a, b) => new Date(a.session.starts_at) - new Date(b.session.starts_at));

  return (
    <>
      <div className="page-head">
        <div>
          <div className="page-date">Free cancellation up to 24 hours before</div>
          <h1 className="page-title">Book a session</h1>
        </div>
      </div>

      <div className="cols">
        <section className="panel">
          <BookingPicker sessions={sessions || []} />
        </section>
        <section className="panel">
          <h2 className="panel-title" style={{ marginBottom: 12 }}>
            Your bookings
          </h2>
          {upcoming.length ? (
            <ul className="rows">
              {upcoming.map((b) => (
                <li key={b.id}>
                  <div className="date-chip">
                    <small>{fmtDay(b.session.starts_at)}</small>
                    <strong>{fmtDayNum(b.session.starts_at)}</strong>
                  </div>
                  <div className="row-main">
                    <strong>{b.session.title}</strong>
                    <span className="meta">
                      {fmtTime(b.session.starts_at)}, {b.session.location || KIND_LABEL[b.session.kind]}
                    </span>
                  </div>
                  <CancelButton id={b.id} action={cancelBooking} />
                </li>
              ))}
            </ul>
          ) : (
            <p className="empty">You have no upcoming bookings.</p>
          )}
        </section>
      </div>
    </>
  );
}

import AppShell from '@/components/AppShell';
import SetupNotice from '@/components/SetupNotice';
import { isConfigured } from '@/lib/supabase/server';
import { requireUser, isStaff } from '@/lib/auth';
import { initials } from '@/lib/format';

export const metadata = { title: 'Client portal' };

const links = [
  { href: '/portal', label: 'Today' },
  { href: '/portal/workouts', label: 'Workout library' },
  { href: '/portal/goals', label: 'Goals' },
  { href: '/portal/book', label: 'Book a session' },
  { href: '/portal/profile', label: 'Profile' },
];

export default async function PortalLayout({ children }) {
  if (!isConfigured()) return <SetupNotice />;
  const { profile } = await requireUser();

  return (
    <AppShell
      links={links}
      label="Client portal"
      name={profile.full_name}
      roleLabel={`${profile.membership || 'Member'} member`}
      initials={initials(profile.full_name)}
      switchLink={isStaff(profile) ? { href: '/admin', label: 'Owner studio' } : null}
    >
      {children}
    </AppShell>
  );
}

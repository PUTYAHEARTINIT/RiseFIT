'use client';

import { useActionState } from 'react';
import { updateProfile } from '../actions';

export default function ProfileForm({ profile }) {
  const [state, action, pending] = useActionState(updateProfile, null);
  return (
    <form action={action} className="stack">
      <div className="grid-2">
        <label className="field">
          Full name
          <input name="full_name" defaultValue={profile.full_name || ''} required />
        </label>
        <label className="field">
          Phone
          <input name="phone" type="tel" defaultValue={profile.phone || ''} />
        </label>
      </div>
      <label className="field">
        Injuries or limitations your coach should know about
        <textarea name="injuries" defaultValue={profile.injuries || ''} />
      </label>
      {state?.notice && (
        <p className="alert" role="status">
          {state.notice}
        </p>
      )}
      {state?.error && (
        <p className="alert alert-err" role="alert">
          {state.error}
        </p>
      )}
      <button className="btn" disabled={pending} style={{ alignSelf: 'flex-start' }}>
        {pending ? 'Saving…' : 'Save profile'}
      </button>
    </form>
  );
}

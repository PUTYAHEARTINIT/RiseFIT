import { requireUser } from '@/lib/auth';
import ProfileForm from './ProfileForm';

export const dynamic = 'force-dynamic';

export default async function Profile() {
  const { profile, user } = await requireUser();
  return (
    <>
      <div className="page-head">
        <div>
          <div className="page-date">{user.email}</div>
          <h1 className="page-title">Profile</h1>
        </div>
      </div>
      <div className="cols">
        <section className="panel">
          <ProfileForm profile={profile} />
        </section>
        <section className="panel panel-mist">
          <div className="stat-label">Membership</div>
          <div className="stat-value">{profile.membership || 'Member'}</div>
          <p className="meta" style={{ marginTop: 12 }}>
            To change or pause your plan, message your coach. Online billing is coming soon.
          </p>
        </section>
      </div>
    </>
  );
}

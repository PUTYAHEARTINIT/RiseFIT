import Link from 'next/link';
import { requireUser } from '@/lib/auth';

export const dynamic = 'force-dynamic';

const LEVELS = ['All', 'Beginner', 'Intermediate', 'Advanced', 'All levels'];

export default async function Library({ searchParams }) {
  const params = await searchParams;
  const level = LEVELS.includes(params?.level) ? params.level : 'All';
  const { supabase } = await requireUser();

  let query = supabase.from('workouts').select('*').eq('status', 'approved').order('created_at', { ascending: false });
  if (level !== 'All') query = query.eq('level', level);
  const { data: workouts } = await query;

  return (
    <>
      <div className="page-head">
        <div>
          <div className="page-date">Every workout here is approved by your coach</div>
          <h1 className="page-title">Workout library</h1>
        </div>
      </div>

      <nav className="choice-row" aria-label="Filter by level">
        {LEVELS.map((l) => (
          <Link
            key={l}
            href={l === 'All' ? '/portal/workouts' : `/portal/workouts?level=${encodeURIComponent(l)}`}
            className="choice"
            aria-pressed={level === l}
            style={{ display: 'inline-flex', alignItems: 'center', textDecoration: 'none' }}
          >
            {l}
          </Link>
        ))}
      </nav>

      {workouts?.length ? (
        <div className="lib">
          {workouts.map((w) => (
            <Link key={w.id} href={`/portal/workouts/${w.id}`} className="lib-card">
              <img src={w.thumbnail_url || '/images/class.jpg'} alt="" />
              <div className="chips">
                {w.duration_min ? <span className="badge">{w.duration_min} min</span> : null}
                {w.level ? <span className="badge badge-line">{w.level}</span> : null}
                {w.focus ? <span className="badge badge-line">{w.focus}</span> : null}
              </div>
              <h3>{w.title}</h3>
              {w.description && <p className="meta">{w.description}</p>}
            </Link>
          ))}
        </div>
      ) : (
        <p className="empty">No workouts here yet. Your coach is adding new ones, so check back soon.</p>
      )}
    </>
  );
}

import Link from 'next/link';
import { notFound } from 'next/navigation';
import { requireUser } from '@/lib/auth';
import Video from '@/components/Video';
import WorkoutLogger from '@/components/WorkoutLogger';

export const dynamic = 'force-dynamic';

export default async function WorkoutDetail({ params }) {
  const { id } = await params;
  const { supabase } = await requireUser();
  const { data: workout } = await supabase.from('workouts').select('*').eq('id', id).eq('status', 'approved').maybeSingle();
  if (!workout) notFound();

  return (
    <>
      <Link href="/portal/workouts" className="link" style={{ alignSelf: 'flex-start' }}>
        Back to the library
      </Link>
      <div className="cols">
        <section className="panel">
          <Video url={workout.video_url} title={workout.title} />
          <WorkoutLogger workout={workout} />
        </section>
        <section className="panel panel-mist">
          <h2 className="panel-title" style={{ marginBottom: 12 }}>
            About this workout
          </h2>
          <p style={{ color: 'var(--graphite)' }}>{workout.description || 'Follow the video and check off each exercise as you go.'}</p>
          {workout.focus && (
            <p className="meta" style={{ marginTop: 16 }}>
              Focus: {workout.focus}
            </p>
          )}
        </section>
      </div>
    </>
  );
}

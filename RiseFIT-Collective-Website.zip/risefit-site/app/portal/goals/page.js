import { requireUser } from '@/lib/auth';
import { fmtDate } from '@/lib/format';
import { addGoal, updateGoal, deleteGoal } from '../actions';

export const dynamic = 'force-dynamic';

export default async function Goals() {
  const { supabase, user } = await requireUser();
  const { data: goals } = await supabase.from('goals').select('*').eq('client_id', user.id).order('created_at');

  return (
    <>
      <div className="page-head">
        <div>
          <div className="page-date">Your coach sees these too</div>
          <h1 className="page-title">Goals</h1>
        </div>
      </div>

      <div className="cols">
        <section className="panel">
          {goals?.length ? (
            <ul className="rows">
              {goals.map((g) => {
                const pct = Math.max(0, Math.min(100, (Number(g.current_value) / Number(g.target_value || 1)) * 100));
                return (
                  <li key={g.id} style={{ display: 'block' }}>
                    <div className="goal-top">
                      <strong style={{ fontFamily: 'var(--serif)', fontSize: 28 }}>{g.title}</strong>
                      <span className="meta">{Math.round(pct)}%</span>
                    </div>
                    <div className="bar" style={{ marginBottom: 12 }}>
                      <span style={{ width: `${pct}%` }} />
                    </div>
                    <div className="inline-form" style={{ justifyContent: 'space-between' }}>
                      <form action={updateGoal} className="inline-form">
                        <input type="hidden" name="id" value={g.id} />
                        <label className="meta" htmlFor={`cv-${g.id}`}>
                          Progress
                        </label>
                        <input id={`cv-${g.id}`} name="current_value" type="number" step="any" defaultValue={g.current_value} style={{ width: 110 }} />
                        <span className="meta">
                          of {g.target_value} {g.unit || ''}
                          {g.target_date ? `, by ${fmtDate(g.target_date + 'T12:00:00', { month: 'short', day: 'numeric', year: 'numeric' })}` : ''}
                        </span>
                        <button className="btn btn-sm">Update</button>
                      </form>
                      <form action={deleteGoal}>
                        <input type="hidden" name="id" value={g.id} />
                        <button className="btn btn-ghost btn-sm">Remove</button>
                      </form>
                    </div>
                  </li>
                );
              })}
            </ul>
          ) : (
            <p className="empty">No goals yet. Add your first one to start tracking it.</p>
          )}
        </section>

        <section className="panel panel-mist">
          <h2 className="panel-title" style={{ marginBottom: 18 }}>
            Add a goal
          </h2>
          <form action={addGoal} className="stack">
            <label className="field">
              What do you want to achieve?
              <input name="title" placeholder="First unassisted pull-up" required />
            </label>
            <div className="grid-2">
              <label className="field">
                Where you are now
                <input name="current_value" type="number" step="any" defaultValue={0} />
              </label>
              <label className="field">
                Target
                <input name="target_value" type="number" step="any" defaultValue={10} required />
              </label>
            </div>
            <div className="grid-2">
              <label className="field">
                Unit
                <input name="unit" placeholder="lb, reps, workouts" />
              </label>
              <label className="field">
                Target date
                <input name="target_date" type="date" />
              </label>
            </div>
            <button className="btn" style={{ alignSelf: 'flex-start' }}>
              Add goal
            </button>
          </form>
        </section>
      </div>
    </>
  );
}

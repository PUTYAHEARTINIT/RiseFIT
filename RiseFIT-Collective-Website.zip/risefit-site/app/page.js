import Link from 'next/link';
import SiteHeader from '@/components/SiteHeader';
import Programs from '@/components/Programs';
import EnrollForm from '@/components/EnrollForm';
import { site } from '@/lib/site';

export default function Home() {
  const { hero, founder, programs, steps, tiers, testimonial, contact } = site;

  return (
    <>
      <SiteHeader />

      <main id="top">
        {/* Hero: the word Rise, filled with the community photo, rises into place once on load */}
        <section className="hero">
          <div className="wrap">
            <div className="hero-top">
              <h1 className="hero-word" aria-label="RiseFIT Collective">
                Rise
              </h1>
              <figure className="hero-portrait">
                <img src="/images/coach-arms.jpg" alt="The RiseFIT coach celebrating with arms raised in a park" />
                <figcaption>
                  <span aria-hidden="true" />
                  Now enrolling
                </figcaption>
              </figure>
            </div>
            <div className="hero-row hero-fade">
              <p className="hero-lede">{hero.lede}</p>
              <div className="hero-side">
                <p>{hero.body}</p>
                <div className="btn-row">
                  <a href="#enroll" className="btn">
                    Book a free intro
                  </a>
                  <a href="#programs" className="btn btn-ghost">
                    See programs
                  </a>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Founder */}
        <section id="about" className="section section-mist">
          <div className="wrap founder">
            <div className="founder-photo">
              <img src="/images/coach-squat.jpg" alt="The RiseFIT coach leading a low squat at an outdoor class" />
            </div>
            <div className="founder-text">
              <span className="kicker">Meet your coach</span>
              <h2>{founder.title}</h2>
              <p>{founder.story}</p>
              <p>{founder.philosophy}</p>
              <blockquote className="founder-quote">{founder.quote}</blockquote>
              <div className="creds">
                {founder.credentials.map((c, i) => (
                  <span key={i} className="cred">
                    {c}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Programs */}
        <section id="programs" className="section">
          <div className="wrap">
            <div className="section-head">
              <h2 className="section-title">Three ways to train with us</h2>
              <p className="section-intro">
                Every membership includes the client portal: your workouts, goals and bookings in one place.
              </p>
            </div>
            <Programs programs={programs} />
          </div>
        </section>

        {/* Community */}
        <section id="community" className="section section-ink">
          <div className="wrap">
            <div className="section-head">
              <h2 className="section-title">More than a workout</h2>
              <p className="section-intro" style={{ color: '#d8d4de' }}>
                From neighborhood Empowerment Workouts to collaborations with local brands, RiseFIT brings every age
                and fitness level together to move and celebrate each other.
              </p>
            </div>
          </div>
          <div className="strip" tabIndex={0} aria-label="Photos from RiseFIT community workouts">
            <figure className="wide">
              <img src="/images/group.jpg" alt="RiseFIT members flexing together after an Empowerment Workout" style={{ objectPosition: '50% 62%' }} />
              <figcaption>The Empowerment Workout crew</figcaption>
            </figure>
            <figure>
              <img src="/images/class.jpg" alt="Members doing high knees in an outdoor class" />
              <figcaption>Outdoor conditioning</figcaption>
            </figure>
            <figure>
              <img src="/images/coach-squat.jpg" alt="The coach leading a movement drill" style={{ objectPosition: '50% 40%' }} />
              <figcaption>Coaching every rep</figcaption>
            </figure>
            <figure>
              <img src="/images/coach-arms.jpg" alt="The coach celebrating with arms raised" style={{ objectPosition: '50% 25%' }} />
              <figcaption>After the last set</figcaption>
            </figure>
          </div>
        </section>

        {/* Steps */}
        <section className="section">
          <div className="wrap">
            <div className="section-head">
              <h2 className="section-title">From first message to first session</h2>
            </div>
            <ol className="steps">
              {steps.map((s) => (
                <li key={s.title}>
                  <h3>{s.title}</h3>
                  <p>{s.text}</p>
                </li>
              ))}
            </ol>
          </div>
        </section>

        {/* Membership */}
        <section id="membership" className="section section-mist">
          <div className="wrap">
            <div className="section-head">
              <h2 className="section-title">Choose your membership</h2>
              <p className="section-intro">Monthly plans. Change or pause any time from your portal.</p>
            </div>
            <div className="tiers">
              {tiers.map((t) => (
                <div key={t.name} className={`tier ${t.featured ? 'tier-featured' : ''}`}>
                  {t.tag && <span className="tier-tag">{t.tag}</span>}
                  <div className="tier-name">{t.name}</div>
                  <div className="tier-price">
                    {t.price}
                    <span> a month</span>
                  </div>
                  <ul>
                    {t.features.map((f) => (
                      <li key={f}>{f}</li>
                    ))}
                  </ul>
                  <a href="#enroll" className={`btn ${t.featured ? 'btn-light' : 'btn-ghost'}`}>
                    {t.cta}
                  </a>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Testimonial */}
        <section className="section">
          <div className="wrap quote-block">
            <blockquote>“{testimonial.quote}”</blockquote>
            <cite>{testimonial.name}</cite>
          </div>
        </section>

        {/* Enrollment */}
        <section id="enroll" className="section section-ink">
          <div className="wrap enroll">
            <div className="enroll-intro">
              <span className="kicker">Enrollment</span>
              <h2>Start your rise</h2>
              <p>Tell us a little about you. We’ll reply within {contact.replyTime} to book your free intro session.</p>
              <div className="enroll-contact">
                <span>{contact.area}</span>
                <span>{contact.email}</span>
                <span>{contact.phone}</span>
                <span>{contact.instagram}</span>
              </div>
            </div>
            <EnrollForm />
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="wrap">
          <img src="/images/logo-white.png" alt="RiseFIT Collective" />
          <nav className="footer-links" aria-label="Footer">
            <a href="/#about">About</a>
            <a href="/#programs">Programs</a>
            <a href="/#membership">Membership</a>
            <Link href="/login">Client login</Link>
            <Link href="/policies">Policies and waiver</Link>
          </nav>
          <div>© {new Date().getFullYear()} RiseFIT Collective</div>
        </div>
      </footer>
    </>
  );
}

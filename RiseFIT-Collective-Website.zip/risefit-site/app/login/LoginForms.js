'use client';

import { useActionState, useState } from 'react';
import { signIn, signUp, sendMagicLink } from './actions';

function Message({ state }) {
  if (!state) return null;
  if (state.error)
    return (
      <p className="alert alert-err" role="alert">
        {state.error}
      </p>
    );
  if (state.notice)
    return (
      <p className="alert" role="status">
        {state.notice}
      </p>
    );
  return null;
}

export default function LoginForms({ next }) {
  const [mode, setMode] = useState('signin');
  const [inState, inAction, inPending] = useActionState(signIn, null);
  const [upState, upAction, upPending] = useActionState(signUp, null);
  const [linkState, linkAction, linkPending] = useActionState(sendMagicLink, null);

  return (
    <>
      <div className="tabs" role="group" aria-label="Sign in or create an account">
        <button type="button" aria-pressed={mode === 'signin'} onClick={() => setMode('signin')}>
          Sign in
        </button>
        <button type="button" aria-pressed={mode === 'signup'} onClick={() => setMode('signup')}>
          Create account
        </button>
      </div>

      {mode === 'signin' ? (
        <div className="stack">
          <form action={inAction} className="stack">
            <input type="hidden" name="next" value={next || ''} />
            <label className="field">
              Email
              <input name="email" type="email" autoComplete="email" required />
            </label>
            <label className="field">
              Password
              <input name="password" type="password" autoComplete="current-password" required />
            </label>
            <Message state={inState} />
            <button className="btn" disabled={inPending}>
              {inPending ? 'Signing in…' : 'Sign in'}
            </button>
          </form>
          <form action={linkAction} className="stack" style={{ marginTop: 12 }}>
            <p className="meta">Forgot your password? We can email you a one-time sign-in link.</p>
            <div className="inline-form">
              <input name="email" type="email" placeholder="you@email.com" aria-label="Email for sign-in link" required style={{ flex: '1 1 220px' }} />
              <button className="btn btn-ghost btn-sm" disabled={linkPending}>
                {linkPending ? 'Sending…' : 'Email me a link'}
              </button>
            </div>
            <Message state={linkState} />
          </form>
        </div>
      ) : (
        <form action={upAction} className="stack">
          <label className="field">
            Full name
            <input name="full_name" autoComplete="name" required />
          </label>
          <div className="grid-2">
            <label className="field">
              Email
              <input name="email" type="email" autoComplete="email" required />
            </label>
            <label className="field">
              Phone
              <input name="phone" type="tel" autoComplete="tel" />
            </label>
          </div>
          <label className="field">
            Password
            <input name="password" type="password" autoComplete="new-password" minLength={8} required />
          </label>
          <label className="check">
            <input type="checkbox" required /> I agree to the{' '}
            <a href="/policies" className="link" target="_blank">
              policies and waiver
            </a>
          </label>
          <Message state={upState} />
          <button className="btn" disabled={upPending}>
            {upPending ? 'Creating account…' : 'Create account'}
          </button>
        </form>
      )}
    </>
  );
}

'use server';

import { headers } from 'next/headers';
import { redirect } from 'next/navigation';
import { createClient, isConfigured } from '@/lib/supabase/server';

async function origin() {
  const h = await headers();
  return h.get('origin') || `https://${h.get('host')}`;
}

function safeNext(value) {
  const v = String(value || '');
  return v.startsWith('/portal') || v.startsWith('/admin') ? v : '';
}

export async function signIn(_prev, formData) {
  if (!isConfigured()) return { error: 'Logins aren’t connected yet. Add the Supabase keys first.' };
  const email = String(formData.get('email') || '').trim();
  const password = String(formData.get('password') || '');
  const supabase = await createClient();
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) {
    return {
      error:
        error.message === 'Email not confirmed'
          ? 'Confirm your email first. Check your inbox for the link we sent.'
          : 'That email and password don’t match. Try again or email yourself a sign-in link.',
    };
  }
  const next = safeNext(formData.get('next'));
  if (next) redirect(next);
  const { data: profile } = await supabase.from('profiles').select('role').eq('id', data.user.id).single();
  redirect(profile?.role === 'owner' || profile?.role === 'trainer' ? '/admin' : '/portal');
}

export async function signUp(_prev, formData) {
  if (!isConfigured()) return { error: 'Logins aren’t connected yet. Add the Supabase keys first.' };
  const email = String(formData.get('email') || '').trim();
  const password = String(formData.get('password') || '');
  const full_name = String(formData.get('full_name') || '').trim();
  const phone = String(formData.get('phone') || '').trim();
  if (password.length < 8) return { error: 'Use at least 8 characters for your password.' };

  const supabase = await createClient();
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: { full_name, phone },
      emailRedirectTo: `${await origin()}/auth/callback?next=/portal`,
    },
  });
  if (error) return { error: error.message };
  if (data.session) redirect('/portal');
  return { notice: `Check ${email} for a link to confirm your account, then come back and sign in.` };
}

export async function sendMagicLink(_prev, formData) {
  if (!isConfigured()) return { error: 'Logins aren’t connected yet. Add the Supabase keys first.' };
  const email = String(formData.get('email') || '').trim();
  if (!email) return { error: 'Enter your email and we’ll send you a sign-in link.' };
  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithOtp({
    email,
    options: { shouldCreateUser: false, emailRedirectTo: `${await origin()}/auth/callback` },
  });
  if (error) return { error: 'We couldn’t send a link to that email. Check it, or create an account.' };
  return { notice: `Sign-in link sent to ${email}. It works once and expires in an hour.` };
}

export async function signOut() {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect('/');
}

import Link from 'next/link';
import LoginForms from './LoginForms';

export const metadata = { title: 'Client login' };

export default async function LoginPage({ searchParams }) {
  const params = await searchParams;
  return (
    <main className="auth">
      <div className="auth-art" role="img" aria-label="The RiseFIT coach celebrating outdoors">
        <img src="/images/logo-white.png" alt="" />
      </div>
      <div className="auth-panel">
        <Link href="/" className="link" style={{ alignSelf: 'flex-start', marginBottom: 40 }}>
          Back to the website
        </Link>
        <h1>Welcome back</h1>
        <p className="sub">Your workouts, goals and bookings are waiting.</p>
        {params?.error && (
          <p className="alert alert-err" role="alert" style={{ marginBottom: 20 }}>
            That link has expired or was already used. Sign in, or ask for a new link.
          </p>
        )}
        <LoginForms next={params?.next} />
      </div>
    </main>
  );
}

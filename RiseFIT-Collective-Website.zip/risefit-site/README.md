# RiseFIT Collective website

A Next.js site with three parts:

- **Public website** (`/`): homepage, programs, community, membership, and an enrollment form that sends requests to the owner.
- **Client portal** (`/portal`): today's assigned workout with a checklist and progress ring, the coach-approved video library, goals, booking, and profile.
- **Owner studio** (`/admin`): overview, remote workout approvals, workout library, schedule, clients, and enrollment requests.

Logins and data are stored in **Supabase** (free tier is plenty to start). The site is hosted on **Vercel**.

---

## Deploy it (about 20 minutes)

### 1. Put the code on GitHub

1. Create a free account at github.com if you don't have one.
2. Click **New repository**, name it `risefit-collective`, keep it **Private**, and create it.
3. On the new repo page, click **uploading an existing file** and drag in everything from this folder.
   (Do not upload `node_modules` or `.next` if you ran it locally.) Click **Commit changes**.

### 2. Set up Supabase (the database and logins)

1. Go to supabase.com, sign up, and click **New project**. Pick a name and a strong database password, and choose the region closest to you (for example East US).
2. When the project is ready, open **SQL Editor** → **New query**.
3. Open `supabase/schema.sql` from this folder, copy everything, paste it in, and click **Run**. You should see "Success".
4. Open **Project Settings** → **API**. Keep this tab open; you need the **Project URL** and the **anon public** key next.

### 3. Deploy on Vercel

1. Go to vercel.com and sign up with your GitHub account.
2. Click **Add New** → **Project**, find `risefit-collective`, and click **Import**.
3. Open **Environment Variables** and add two:
   - `NEXT_PUBLIC_SUPABASE_URL` = the Project URL from Supabase
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY` = the anon public key from Supabase
4. Click **Deploy**. In a minute or two you'll get a live link like `risefit-collective.vercel.app`.

### 4. Connect logins to your live address

In Supabase, open **Authentication** → **URL Configuration**:

- **Site URL**: your live address, for example `https://risefit-collective.vercel.app` (or your own domain later)
- **Redirect URLs**: add `https://risefit-collective.vercel.app/auth/callback`

This makes the "confirm your email" and "email me a sign-in link" emails open your site.

### 5. Make yourself the owner

1. On your live site, click **Client login** → **Create account** and sign up with your email. Confirm it from your inbox.
2. In Supabase **SQL Editor**, run (with your email):

   ```sql
   update public.profiles set role = 'owner' where email = 'you@example.com';
   ```

3. Sign in again. You'll land in the **Owner studio** at `/admin`.

To add a trainer later: have them create an account, then open **Clients** in the owner studio, pick their name, and change **Account role** to Trainer.

### 6. Add your own domain (optional)

In Vercel, open the project → **Settings** → **Domains**, add `risefitcollective.com` (or whatever you own), and follow the DNS steps. Then update the two URLs in step 4 to the new domain.

---

## How the owner uses it

1. **Schedule**: add your bookable times (1:1 sessions, group classes, check-ins). Set the number of spots and repeat weekly if you like. Clients can only book what's here.
2. **Workout library**: add a workout with a title, a YouTube/Vimeo/MP4 link, and exercises (one per line, `Goblet squat | 4 × 10`). As the owner you can publish immediately.
3. **Approvals**: anything a trainer adds waits here. Preview it, then **Approve and publish** or **Request changes** with a note. Clients never see unapproved workouts; this is enforced in the database, not just the screen.
4. **Clients**: open a client to assign a workout for a specific day, leave a note that shows on their dashboard, see their logged workouts and notes, goals and bookings.
5. **Enrollments**: requests from the homepage form. Mark them Contacted, Enrolled or Archived.

## How clients use it

1. Create an account from **Client login**.
2. **Today** shows their assigned workout: watch the video, tap each exercise as they finish it, add notes, and **Finish and log workout**.
3. **Workout library** has every approved workout to do any time.
4. **Goals** lets them set targets and update progress.
5. **Book a session** shows open times; they can cancel up to 24 hours before.

---

## Editing the website words and prices

All homepage text, prices, program descriptions and contact details live in **`lib/site.js`**. Anything in `[brackets]` is a placeholder. Edit that file on GitHub (open it, click the pencil, change the text, commit) and Vercel redeploys automatically in about a minute.

Photos are in `public/images/`. To swap one, upload a new file with the same name.

The policies page is `app/policies/page.js`. Have your waiver text reviewed before you paste it in.

## Running it on your computer (optional)

You need Node.js 18.18 or newer.

```bash
npm install
cp .env.example .env.local   # then paste your two Supabase values into .env.local
npm run dev                   # open http://localhost:3000
```

## What's included and what's next

| Included now | Next phase |
| --- | --- |
| Enrollment form, accounts, email confirmation and sign-in links | Online payments and memberships (Stripe) |
| Booking with capacity limits and a 24-hour cancellation rule | Text and email reminders before sessions |
| Coach-approved workout library and owner approval flow | Direct messaging and form-check video uploads |
| Assigned workouts, logging, streaks and goals | Challenges, badges and leaderboards |
| Owner studio: schedule, clients, approvals, enrollments | Progress photos and body measurements |

## Tech notes

- Next.js 15 (App Router), React 19, plain CSS (`app/globals.css`), self-hosted fonts (Cormorant Garamond and Jost).
- Supabase Auth and Postgres with row-level security. Roles: `client`, `trainer`, `owner`. Only the owner can approve workouts or change roles, enforced by database triggers.
- Timezone for display and scheduling is America/New_York (`lib/format.js` and `app/admin/actions.js`).
